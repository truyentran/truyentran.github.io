/*
	CRF-SL: Conditional Random Fields for Sequential Labelling

	Copyright (C) 2006-2008 Tran The Truyen <thetruyen.tran@postgrad.curtin.edu.au>
	This is free software with ABSOLUTELY NO WARRANTY.
  
	This library is free software; you can redistribute it and/or
	modify it under the terms of the GNU Lesser General Public
	License as published by the Free Software Foundation; either
	version 2.1 of the License, or (at your option) any later version.
  
	This library is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
	Lesser General Public License for more details.
  
	You should have received a copy of the GNU Lesser General Public
	License along with this library; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/


#if !defined(_SEQFEATURE_H_)
#define _SEQFEATURE_H_

/* 
	The Database Manager of sequential features. Support following operations:
		+extract features from file, organise features into data-base
		+monitor feature stream for other use
*/
class SeqFeature
{
public:
	int getFeatureType();

	void setCurrLabel(int label);
	int getObsFeatureSize();
	void setSeqLens(int *lens, int seq_no);
	void setSeqIndex(int seq_i);

	int getSeqLen(int sq);
	int getSeqNo();

	void setLabelSize(int label_size);
	int getNodeNo();

	int getNextDataPattern(int t, double *f, int *f_ID, bool restart);

	//read pre-computed feature files
	int readDataPatternFile(char *file_name);

	// these write functions are for testing purposes only!
	void writeDataPatternFile(char *file_name);

	SeqFeature();
	SeqFeature(int st_size);
	virtual ~SeqFeature();

private:
	//defining a feature structure of a node in the database
	struct NodeFeature
	{
		int len; //length of vector
		double *val; //vector of observational features
		int *index; //vetor of indexes of features
		int *label_start; //array indexes of the starting point for each label
		int *label; //the labels being activated at this node
	};

	void init();
	void clean();
	NodeFeature *feature_sq; //an array of TxS NodeFeature for ONE sequence
	NodeFeature *feature_all; //FEATURE DATABASE: an array of TxSxD NodeFeature for all sequences
	int LABEL_SIZE; //label size
	int NODE_NO; //number of nodes in the whole databases (including delimiter nodes)
	
	int curr_t; //the current time being queried
	int node_f_index;

	int *seq_start_index; //holding node index of the starting node of the sequence in the whole database

	/*
		this is assumed to be indentical to those read from the taggs-data
		however, this must be used during inference (no taggs available)
	*/
	int *seq_lenx; 
	int *seq_lens;


	bool SEQ_LEN_INITED;
	bool DATABASE_LOADED;

	int curr_sq;
	int curr_label;
	
	int OB_F_MAX; 
	int SEQ_NO;

};

#endif // !defined(_SEQFEATURE_H_)
