/*
	CRF-SL: Conditional Random Fields for Sequential Labelling

	Copyright (C) 2006-2008 Tran The Truyen <thetruyen.tran@postgrad.curtin.edu.au>
	This is free software with ABSOLUTELY NO WARRANTY.
  
	This library is free software; you can redistribute it and/or
	modify it under the terms of the GNU Lesser General Public
	License as published by the Free Software Foundation; either
	version 2.1 of the License, or (at your option) any later version.
  
	This library is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
	Lesser General Public License for more details.
  
	You should have received a copy of the GNU Lesser General Public
	License along with this library; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/


// This is a test driver for the noun-phrase chunking problem

#include <iostream>
#include <fstream>
#include <time.h>
#include <stdlib.h>
#include <string.h>

#include "SeqClassifier.h"
#include "Evaluator.h"
#include "utility.h"

#define VP		1 //Voted Perceptron by Collin
#define ONLINE	2 //Stochastic Gradient
#define BFGS	3 //Limited Memory L-BFGS

#define ON		1
#define OFF		0

#define LABEL	1
#define SEGMENT	2

int parseConfig(char *file_name);


int NODE_FEATURE		= ON;
int TRANSIT_FEATURE		= OFF;
int MARKOV_ORDER		= 1;
int OPT_ALGO			= ONLINE;
int ITERATIONS			= 20;
double CONVERGENCE		= 1e-5;
double LEARNING_RATE	= 0.1;
double STDEV			= 3.0;
int FEATURE_CUTOFF		= 3;
int LABEL_SIZE			= 3;
bool PARAM_LOG			= ON;
bool PARAM_INIT			= OFF;
bool TRAINING			= ON;
bool TESTING			= ON;
int REPORT				= LABEL;

char TRAIN_FEATURE_FILE[1024];
char TEST_FEATURE_FILE[1024];
char TRAIN_LABEL_FILE[1024];
char TEST_LABEL_FILE[1024];
 
using namespace std;

int main()
{
	//---- parsing config file ------------
	parseConfig("run.conf");

    clock_t start = clock();
    clock_t finish;

	Evaluator *eval;
	SeqClassifier *classifier;

	//------- training time --------------
	if(TRAINING)
	{
		classifier = new SeqClassifier(LABEL_SIZE,MARKOV_ORDER,NODE_FEATURE,TRANSIT_FEATURE);

		cout << "Loading training features & tag files... " << endl;
		
		classifier->prepareLabels(TRAIN_LABEL_FILE);
		classifier->prepareDataPattern(TRAIN_FEATURE_FILE);

		finish = clock();
		cout << "Training loading time: " << (double)(finish-start)/ CLOCKS_PER_SEC << endl;
		start = finish;

		if(MARKOV_ORDER == 1)
		{
			cout << "Training First-Order CRF ... " << endl;
		}else if(MARKOV_ORDER == 2)
		{
			cout << "Training Second-Order CRF ... " << endl;
		}

		if(OPT_ALGO == BFGS)
		{
			cout << "Running L-BFGS  ... " << endl;
			classifier->trainCRF(ITERATIONS,PARAM_INIT,PARAM_LOG,(double)STDEV,CONVERGENCE);
		}else if(OPT_ALGO == ONLINE)
		{
			cout << "Running Stochastic Gradient Ascent  ... " << endl;
			classifier->trainOnline(ITERATIONS,(double)LEARNING_RATE,PARAM_INIT,PARAM_LOG,(double)STDEV);
		}else
		{
			cout << "Running Collin's Voted Perceptron  ... " << endl;
			classifier->trainPerceptron(ITERATIONS,PARAM_INIT,PARAM_LOG);
		}

		finish = clock();
		cout << "Training time: " << (double)(finish-start)/ CLOCKS_PER_SEC << endl;
		start = finish;

		delete classifier;
	}if(TESTING)
	{
		classifier = new SeqClassifier(LABEL_SIZE,MARKOV_ORDER,NODE_FEATURE,TRANSIT_FEATURE);

		cout << "Loading testing features ... " << endl;
		classifier->prepareDataPattern(TEST_FEATURE_FILE);

		finish = clock();
		cout << "Testing loading time: " << (double)(finish-start)/ CLOCKS_PER_SEC << endl;
		start = finish;
			
		//evaluation
		eval =  new Evaluator(LABEL_SIZE);

		cout << "Loading test tag file ... " << endl;
		eval->readTestLabels(TEST_LABEL_FILE);

		cout << "Predicting labels ... " << endl;
		classifier->predictLabels(eval);

		if(REPORT == LABEL)
		{
			eval->reportLabelWise();
		}else
		{
			eval->reportSegmentWise();
		}

		finish = clock();
		cout << "Testing time: " << (double)(finish-start)/ CLOCKS_PER_SEC << endl;
		start = finish;

		delete classifier;
		delete eval;
	}

 	return 0;
};

// parsing configuration file
int parseConfig(char *file_name)
{
	ifstream input;
	char line[1024];
	char name[1024],value[1024];
	int i,j;
	
	input.open(file_name);

	//check for wrong input file
	if (!input)
	{
		cout << "\n";
		cout << "parseConfig() - Fatal error!\n";
		cout << "Could not read configuration file: \"" << file_name << "\"\n";
		return 0;
	}

	while (input.getline(line,sizeof(line)) && !(input.eof()))
	{
		i = 0;

		if (line[0] == '#' || s_len_trim(line) == 0)
		{ //this is a comment or empty line, ignore
			continue;
		}

		//get the variable name
		j = 0;
		while(line[i] != '\0')
		{
			if(line[i] == ' ' || line[i] == '\t')
			{ 
				name[j] = '\0';
				j = 0;
				break;
			}else
			{
				name[j] = line[i];
				j++;
			}
			i++;
		}

		//remove all the empty spaces or equal sign
		while(line[i] == ' ' || line[i] == '\t' || line[i] == '=')
		{
			i++;
			//do nothing
		}

		//get the variable value
		j=0;
		while(line[i] != '\0' && line[i] != ' ' && line[i] != '\t' )
		{
			value[j] = line[i];
			i++;
			j++;
		}
		value[j] = '\0';

		if(strcmp(name,"NODE_FEATURE")==0)
		{
			NODE_FEATURE = OFF;
			if(strcmp(value,"ON")==0)
			{
				NODE_FEATURE = ON;
			}

		}else if(strcmp(name,"TRANSIT_FEATURE")==0)
		{
			TRANSIT_FEATURE = OFF;
			if(strcmp(value,"ON")==0)
			{
				TRANSIT_FEATURE = ON;
			}
		}else if(strcmp(name,"MARKOV_ORDER")==0)
		{
			MARKOV_ORDER = atoi(value);
		}else if(strcmp(name,"OPT_ALGO")==0)
		{
			OPT_ALGO = ONLINE;
			if(strcmp(value,"VP")==0)
			{
				OPT_ALGO = VP;
			}else if(strcmp(value,"BFGS")==0)
			{
				OPT_ALGO = BFGS;
			}
		}else if(strcmp(name,"ITERATIONS")==0)
		{
			ITERATIONS = atoi(value);
		}else if(strcmp(name,"CONVERGENCE")==0)
		{
			CONVERGENCE = atof(value);
		}else if(strcmp(name,"LEARNING_RATE")==0)
		{
			LEARNING_RATE = atof(value);
		}else if(strcmp(name,"STDEV")==0)
		{
			STDEV = atof(value);
		}else if(strcmp(name,"FEATURE_CUTOFF")==0)
		{
			FEATURE_CUTOFF = atoi(value);

		}else if(strcmp(name,"LABEL_SIZE")==0)
		{
			LABEL_SIZE = atoi(value);
		}else if(strcmp(name,"PARAM_LOG")==0)
		{
			PARAM_LOG = OFF;
			if(strcmp(value,"ON")==0)
			{
				PARAM_LOG = ON;
			}
		}else if(strcmp(name,"PARAM_INIT")==0)
		{
			PARAM_INIT = OFF;
			if(strcmp(value,"ON")==0)
			{
				PARAM_INIT = ON;
			}
		}else if(strcmp(name,"TRAINING")==0)
		{
			TRAINING = OFF;
			if(strcmp(value,"ON")==0)
			{
				TRAINING = ON;
			}
		}else if(strcmp(name,"TESTING")==0)
		{
			TESTING = OFF;
			if(strcmp(value,"ON")==0)
			{
				TESTING = ON;
			}
		}else if(strcmp(name,"REPORT")==0)
		{
			REPORT = LABEL;
			if(strcmp(value,"SEGMENT")==0)
			{
				REPORT = SEGMENT;
			}
		}else if(strcmp(name,"TRAIN_FEATURE_FILE")==0)
		{
			strcpy(TRAIN_FEATURE_FILE,value);
		}else if(strcmp(name,"TEST_FEATURE_FILE")==0)
		{
			strcpy(TEST_FEATURE_FILE,value);
		}else if(strcmp(name,"TRAIN_LABEL_FILE")==0)
		{
			strcpy(TRAIN_LABEL_FILE,value);
		}else if(strcmp(name,"TEST_LABEL_FILE")==0)
		{
			strcpy(TEST_LABEL_FILE,value);
		}
	}

	input.clear();
	input.close();

	return 1;
}
