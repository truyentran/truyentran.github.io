/*
	CRF-SL: Conditional Random Fields for Sequential Labelling

	Copyright (C) 2006-2008 Tran The Truyen <thetruyen.tran@postgrad.curtin.edu.au>
	This is free software with ABSOLUTELY NO WARRANTY.
  
	This library is free software; you can redistribute it and/or
	modify it under the terms of the GNU Lesser General Public
	License as published by the Free Software Foundation; either
	version 2.1 of the License, or (at your option) any later version.
  
	This library is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
	Lesser General Public License for more details.
  
	You should have received a copy of the GNU Lesser General Public
	License along with this library; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/


#if !defined(_SEQCLASSIFIER_H_)
#define _SEQCLASSIFIER_H_

#include "SeqCRF.h"	// Added by ClassView
#include "SeqFeature.h"	// Added by ClassView
#include "Evaluator.h"
#include "Label.h"

/*
	This class is a wrapper class for CRFs to 
	manage all activities:
		+ read labels
		+ read pre-computed features
		+ train CRFs
		+ predict labels

	Each CRF variant should have one wrapper like this one.
*/
class SeqClassifier  
{
public:
	void trainPerceptron(int nIterations,bool init_param, bool save_param);
	void trainCRF(int nIterations,bool init_param, bool save_param, double stdev, double epsilon);
	void trainOnline(int nIterations, double learning_rate,bool init_param, bool save_param, double stdev);

	void prepareLabels(char *label_file);
	void prepareDataPattern(char *feature_file);

	void predictLabels(Evaluator *eval);

	SeqClassifier(int st_size, int order, int node_feature, int transit_feature);
	virtual ~SeqClassifier();

private:
	double computeGrad(double *grad, double sigma);
	void loadParam(char *file_name);
	void saveParam(char *file_name);
	void initParam();
	SeqFeature *feature;

	Label *label_all;

	int OB_F_SIZE; //raw size of observational features
	int NODE_VEC_SIZE;
	int TRANSIT_VEC_SIZE;
	int TRINODE_VEC_SIZE;
	int PARAM_VEC_SIZE;

	int LABEL_SIZE;
	int SEQ_NO;
	int MARKOV_ORDER;

	double *node_param;
	double *transit_param;
	double *trinode_param;
	double *param;
	char *param_file;

	bool PARAM_INITED;

	int NODE_FEATURE;
	int TRANSIT_FEATURE;

};

#endif // !defined(_SEQCLASSIFIER_H_)
