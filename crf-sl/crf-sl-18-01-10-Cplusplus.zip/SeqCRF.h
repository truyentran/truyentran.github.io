/*
	CRF-SL: Conditional Random Fields for Sequential Labelling

	Copyright (C) 2006-2008 Tran The Truyen <thetruyen.tran@postgrad.curtin.edu.au>
	This is free software with ABSOLUTELY NO WARRANTY.
  
	This library is free software; you can redistribute it and/or
	modify it under the terms of the GNU Lesser General Public
	License as published by the Free Software Foundation; either
	version 2.1 of the License, or (at your option) any later version.
  
	This library is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
	Lesser General Public License for more details.
  
	You should have received a copy of the GNU Lesser General Public
	License along with this library; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/


#if !defined(_SEQCRF_H_)
#define _SEQCRF_H_


#include "utility.h"
#include "SeqFeature.h"

#define node_param(index) node_param[index]
#define transit_param(pre_label,label) transit_param[(pre_label-1)*LABEL_SIZE+label-1]
#define trinode_param(pre_label,label,post_label) trinode_param[(pre_label-1)*LABEL_SIZE*LABEL_SIZE + (label-1)*LABEL_SIZE + post_label-1]

#define node_f_index(label,f_ID) ((label-1)*OB_F_SIZE + f_ID-1)

#define transit_st_index(pre_label,label) ((pre_label-1)*LABEL_SIZE + label-1)
#define transit_f_index(pre_label,label,f_ID) (((pre_label-1)*LABEL_SIZE + label-1)*OB_F_SIZE + f_ID-1)

#define label_data(t) label_data[t-1]
#define label_predicts(t) label_predicts[t-1]

#define FIRST	1 //the order of Markov process
#define SECOND	2

class SeqFeature;

//CRF for Sequential Labelling
class SeqCRF
{
public:
	void getMAP(int *label_predicts);
	void setLabel(int *label);
	void setParam(double *node_paramx);
	void setParam(double *node_paramx, double *transit_paramx);
	void setParam(double *node_paramx, double *transit_paramx, double *trinode_paramx);

	double getGrad(double *node_grad, double *transit_grad);
	double getGradFull(double *node_grad, double *transit_grad);
	double getGrad(double *node_grad, double *transit_grad, double *trinode_grad);
	double getGradFull(double *node_grad, double *transit_grad, double *trinode_grad);

	SeqCRF(SeqFeature *ftr, int seq_len, int label_size, int ob_f_size,int order, int node_feature, int transit_feature);
	virtual ~SeqCRF();

private:
	struct MarkovUnit
	{
		int len; //length of array
		double *val; //array holding values
	};

	double computeFeatureExpectEmpi();

	void viterbi(int *label_predicts);
	void viterbiBackward(int *label_predicts);

	void maxProdFirstOrder(int *label_predicts);
	void maxProdSecondOrder(int *label_predicts);

	void initStSet(int mode);
	void clearStSet();

	void initMargin();
	double computeMarginFirstOrder();
	double computeMarginSecondOrder();
	void clearMargin();

	void computeFeatureExpect();

	void initPoten();
	void computePoten();
	void clearPoten();

	//Pearl's belief propagation
	void initMsg();
	void clearMsg();
	
	SeqFeature *feature; //the databased holding precomputed features

	int LABEL_SIZE;
	int OB_F_SIZE;
	int SEQ_LEN;
	int MARKOV_ORDER;

	int *label_data; //label sequence used in training

	double *node_param; //node-based parameter vector
	double *transit_param; //transit-based parameter vector
	double *trinode_param; //second-order transition parameter vector

	MarkovUnit *node_poten; //T*S
	MarkovUnit *transit_poten; //(T-1)*S*S
	double *trinode_poten; //S*S*S

	MarkovUnit *forward;
	MarkovUnit *backward;
	MarkovUnit *node_margin; //T*S
	MarkovUnit *transit_margin;// (T-1)*S*S
	MarkovUnit *trinode_margin;// (T-2)*S*S*S

	MarkovUnit *label_set; //all states per node

	bool F_EXPECT_INITED; //indicator
	bool POTEN_INITED; //true if potentials have been initialised
	bool POTEN_COMPUTED; //true if potentials have been computed
	bool MARGIN_INITED; //true if potentials have been computed
	bool LABEL_SET_INITED; //true if the set of states per node have been initialised
	bool MSG_INITED; //true if the messages have been initialised

	int NODE_VEC_SIZE;
	int TRANSIT_VEC_SIZE;
	int TRINODE_VEC_SIZE;

	int NODE_FEATURE;
	int TRANSIT_FEATURE;

	//expectation of feature used in gradient-based learning
	double *node_f_expect; 
	double *transit_f_expect;
	double *trinode_f_expect;
};

#endif // !defined(_SEQCRF_H_)
