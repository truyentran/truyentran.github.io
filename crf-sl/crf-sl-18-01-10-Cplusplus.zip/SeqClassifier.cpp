/*
	CRF-SL: Conditional Random Fields for Sequential Labelling

	Copyright (C) 2006-2008 Tran The Truyen <thetruyen.tran@postgrad.curtin.edu.au>
	This is free software with ABSOLUTELY NO WARRANTY.
  
	This library is free software; you can redistribute it and/or
	modify it under the terms of the GNU Lesser General Public
	License as published by the Free Software Foundation; either
	version 2.1 of the License, or (at your option) any later version.
  
	This library is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
	Lesser General Public License for more details.
  
	You should have received a copy of the GNU Lesser General Public
	License along with this library; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/


#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <math.h>
#include <time.h>

#include "SeqClassifier.h"
#include "utility.h"

extern "C" {
  extern void lbfgs(int* n, int* m, double* x, double* f, double* g, 
		    int* diagco, double* diag, int* iprint, double* eps, 
		    double* xtol, double* w, int* iflag);
}

using namespace std;

SeqClassifier::SeqClassifier(int st_size, int order, int node_feature, int transit_feature)
{
	LABEL_SIZE = st_size;
	MARKOV_ORDER = order;

	feature = new SeqFeature(LABEL_SIZE);
	label_all = NULL;

	OB_F_SIZE = 0; //in case of no raw features
	NODE_VEC_SIZE = 1;
	TRANSIT_VEC_SIZE = LABEL_SIZE*LABEL_SIZE;
	TRINODE_VEC_SIZE = 0;
	PARAM_VEC_SIZE = 1;

	PARAM_INITED = false;

	if(MARKOV_ORDER == FIRST)
	{
		param_file = "seq_param_1order.txt";
	}else if(MARKOV_ORDER == SECOND)
	{
		param_file = "seq_param_2order.txt";
	}


	NODE_FEATURE = node_feature;
	TRANSIT_FEATURE = transit_feature;

	node_param = NULL;
	transit_param = NULL;
	trinode_param = NULL;
}

SeqClassifier::~SeqClassifier()
{
	delete feature;
	if(label_all)
	{
		delete label_all;
	}

	if(PARAM_INITED)
	{
		delete [] node_param;
		delete [] transit_param;

		if(MARKOV_ORDER == SECOND)
		{
			delete [] trinode_param;
		}
	}
}

//load the labels
void SeqClassifier::prepareLabels(char *label_file)
{
	label_all = new Label();
	label_all->readLabels(label_file);

	feature->setSeqLens(label_all->getSeqLens(),label_all->getSeqNo());

}

//load RAW features
void SeqClassifier::prepareDataPattern(char *feature_file)
{
	feature->readDataPatternFile(feature_file);

	OB_F_SIZE = feature->getObsFeatureSize();
	SEQ_NO = feature->getSeqNo();
}

/*
	sum of gradients of all sequences

	returns
		- gradient
		- log-likelihood
*/
double SeqClassifier::computeGrad(double *grad, double stdev)
{
	int seq_i,f;
	SeqCRF *crf;

	int seq_len;
	double ll=0;

	double *node_grad = new double[NODE_VEC_SIZE];
	double *transit_grad = new double[TRANSIT_VEC_SIZE];
	double *node_grad_all = new double[NODE_VEC_SIZE];
	double *transit_grad_all = new double[TRANSIT_VEC_SIZE];

	double *trinode_grad = NULL;
	double *trinode_grad_all = NULL;

	zeros(node_grad_all,NODE_VEC_SIZE);
	zeros(transit_grad_all,TRANSIT_VEC_SIZE);

	extract(node_param,param,0,NODE_VEC_SIZE);
	extract(transit_param,param,NODE_VEC_SIZE,TRANSIT_VEC_SIZE);

	if(MARKOV_ORDER == SECOND)
	{
		trinode_grad = new double[TRINODE_VEC_SIZE];
		trinode_grad_all = new double[TRINODE_VEC_SIZE];

		zeros(trinode_grad_all,TRINODE_VEC_SIZE);
		extract(trinode_param,param,NODE_VEC_SIZE+TRANSIT_VEC_SIZE,TRINODE_VEC_SIZE);
	}

	for(seq_i=0; seq_i < SEQ_NO; seq_i++)
	{

		seq_len = feature->getSeqLen(seq_i);
		feature->setSeqIndex(seq_i);

		if(MARKOV_ORDER == FIRST || seq_len <= 2)
		{
			crf = new SeqCRF(feature,seq_len,LABEL_SIZE, OB_F_SIZE,FIRST, NODE_FEATURE, TRANSIT_FEATURE);
			crf->setLabel(label_all->getLabels(seq_i));
			crf->setParam(node_param,transit_param);

			//compute the gradient
			ll += crf->getGrad(node_grad,transit_grad);
		}else if(MARKOV_ORDER == SECOND)
		{
			crf = new SeqCRF(feature,seq_len,LABEL_SIZE, OB_F_SIZE, SECOND, NODE_FEATURE, TRANSIT_FEATURE);
			crf->setLabel(label_all->getLabels(seq_i));
			crf->setParam(node_param,transit_param, trinode_param);

			//compute the gradient
			ll += crf->getGrad(node_grad,transit_grad, trinode_grad);
			add_vector(trinode_grad_all,trinode_grad,TRINODE_VEC_SIZE);
		}
		add_vector(node_grad_all,node_grad,NODE_VEC_SIZE);
		add_vector(transit_grad_all,transit_grad,TRANSIT_VEC_SIZE);

		delete crf;
	}
	insert(node_grad_all,grad,0,NODE_VEC_SIZE);
	insert(transit_grad_all,grad,NODE_VEC_SIZE,TRANSIT_VEC_SIZE);
	if(MARKOV_ORDER == SECOND)
	{
		insert(trinode_grad_all,grad,NODE_VEC_SIZE+TRANSIT_VEC_SIZE,TRINODE_VEC_SIZE);
	}
	//regularisation
	for(f=0; f < PARAM_VEC_SIZE; f++)
	{
		ll -= param[f]*param[f]/(2*stdev*stdev);
		grad[f] -= param[f]/(stdev*stdev);
	}

	//scaling down
	ll = ll/SEQ_NO;
	multi_scalar(grad,(double)1.0/SEQ_NO,PARAM_VEC_SIZE);

	delete [] node_grad;
	delete [] transit_grad;
	delete [] node_grad_all;
	delete [] transit_grad_all;

	if(MARKOV_ORDER == SECOND)
	{
		delete [] trinode_grad;
		delete [] trinode_grad_all;
	}

	return ll;
}

/*
	training CRF using the L-BFGS algorithm
*/
void SeqClassifier::trainCRF(int nIterations, bool init_param, bool save_param, double stdev, double epsilon)
{
	clock_t start=clock(),finish=0;
	double ll;
	
	//initialise parameters
	if(!PARAM_INITED)
	{
		this->initParam();
	}
	param = new double[PARAM_VEC_SIZE];
	zeros(param,PARAM_VEC_SIZE);

	if(init_param)
	{
		this->loadParam(param_file);
	}

	//--- training parameters -----------
	int Hessian_vector_no = 10; //number of vectors to approximate Hessian
	
    // indicate whether or not user provide the diagonal matrix Hk0
    // at each iteration (here we chose "not provide", i.e., diagco = false)
    int diagco = 0;	 

    // diag is only for LBFGS optimization
    double *diag = new double[PARAM_VEC_SIZE];

    // allocate memory for ws (workspace)
    // this memory is only for LBFGS optimization
    int ws_size = PARAM_VEC_SIZE*(2*Hessian_vector_no + 1) + 2*Hessian_vector_no;
    double *ws = new double[ws_size];
    int iprint[] = {-1, 0};
    double xtol = (double)1.0e-16; // machine precision
    int iflag = 0; //execution flag of LBFGS optimiser
	//-----------------------------------

	double *grad = new double [PARAM_VEC_SIZE];

	//the main training loop
	for(int iter=1; iter <= nIterations; iter++)
	{
		ll = this->computeGrad(grad,stdev);

		// ----- L-BFGS optimiser ----------
		// convert maximiser into minimiser
		ll *= -1;
		multi_scalar(grad,-1.0,PARAM_VEC_SIZE);

		// calling LBFGS optimization routine
		lbfgs(&PARAM_VEC_SIZE, &Hessian_vector_no, (double *)param, &ll, (double *)grad, &diagco, 
				(double *)diag, iprint, &epsilon, &xtol, (double *)ws, &iflag);

		if (iflag < 0)
		{ //ERROR
			printf("LBFGS routine encounters an error\n");
			break;
		}else if (iflag == 0)
		{ //terminate
			break;
		}

		finish = clock();
		cout << "\titer: " << iter << " log(ll): " << -ll << " time: " << (double)(finish-start)/CLOCKS_PER_SEC << endl;
	}

	delete [] grad;
    delete [] diag;
    delete [] ws;
	delete [] param;

	this->saveParam(param_file);
}

/*
	Voted Perceptron algorithm
	#Ref: M. Collins, "Discriminative Training Methods for Hidden Markov
		Models: Theory and Experiments with Perceptron 
		Algorithms", Proc. ENLP, 2002.
*/
void SeqClassifier::trainPerceptron(int nIterations,bool init_param, bool save_param)
{
	clock_t start=clock(),finish=0;

	int seq_i,seq_ix,iter,label,t,post_label,post_post_st,predict,post_predict,f_ID;
	double f;
	int flag;

	//initialise parameters
	if(!PARAM_INITED)
	{
		this->initParam();
	}

	if(init_param)
	{
		this->loadParam(param_file);
	}

	//--- training parameters -----------
	double learning_rate = (double)0.001;
	//-----------------------------------

	int seq_len;
	int err = 0,pre_err=0;
	bool match_sq=true;
	int update_no=0;

	double *node_param_sum = new double[NODE_VEC_SIZE];
	zeros(node_param_sum,NODE_VEC_SIZE);

	double *transit_param_sum = NULL;
	transit_param_sum = new double[TRANSIT_VEC_SIZE];
	zeros(transit_param_sum,TRANSIT_VEC_SIZE);

	double *trinode_param_sum = NULL;
	if(MARKOV_ORDER == SECOND)
	{
		trinode_param_sum = new double[TRINODE_VEC_SIZE];
		zeros(trinode_param_sum,TRINODE_VEC_SIZE);
	}

	//-------- main training loops ---------------------
	for(iter=0; iter < nIterations; iter++)
	{
		err = 0;
		for(seq_ix=0; seq_ix < SEQ_NO; seq_ix++)
		{
			seq_i = seq_ix;

			seq_len = feature->getSeqLen(seq_i);

			SeqCRF *crf = new SeqCRF(feature,seq_len,LABEL_SIZE, OB_F_SIZE, MARKOV_ORDER, NODE_FEATURE, TRANSIT_FEATURE);

			feature->setSeqIndex(seq_i);
			if(MARKOV_ORDER == FIRST)
			{
				crf->setParam(node_param,transit_param);
			}else
			{
				crf->setParam(node_param,transit_param, trinode_param);
			}

			int *label_data = label_all->getLabels(seq_i);

			//compute the gradient
			int *label_predicts = new int[seq_len];
			crf->getMAP(label_predicts);

			match_sq = true;

			if(NODE_FEATURE)
			{
				for(t=1; t <= seq_len; t++)
				{	
					label = label_data(t);
					if(label != label_predicts(t))
					{
						match_sq = false;

						flag = feature->getNextDataPattern(t,&f,&f_ID,true);
						while(flag)
						{
							node_param[node_f_index(label,f_ID)] += learning_rate*f;
							flag = feature->getNextDataPattern(t,&f,&f_ID,false);
						}
					}
				}
			}

			if(TRANSIT_FEATURE)
			{
				for(t=1; t <= seq_len-1; t++)
				{	
					label			= label_data(t);
					post_label		= label_data(t+1);
					predict			= label_predicts(t);
					post_predict	= label_predicts(t+1);
					
					if(label != predict || post_label != post_predict)
					{
						match_sq = false;

						flag = feature->getNextDataPattern(t,&f,&f_ID,true);
						while(flag)
						{
							transit_param[transit_f_index(label,post_label,f_ID)] += learning_rate*f;
							transit_param[transit_f_index(predict,post_predict,f_ID)] -= learning_rate*f;

							flag = feature->getNextDataPattern(t,&f,&f_ID,false);
						}
					}
				}
			}

			if(MARKOV_ORDER == SECOND)
			{
				for(t=1; t <= seq_len-2; t++)
				{	
					label				= label_data(t);
					post_label			= label_data(t+1);
					post_post_st		= label_data(t+2);
					if(label != label_predicts(t) || post_label != label_predicts(t+1) ||
							post_post_st != label_predicts(t+2))
					{
						match_sq = false;

						trinode_param(label,post_label,post_post_st) += learning_rate;

						trinode_param(label_predicts(t),label_predicts(t+1),label_predicts(t+2)) -= learning_rate;
					}
				}

			}
			if(!match_sq)
			{
				err++;
			}

			update_no ++;
			for(f_ID=0; f_ID < NODE_VEC_SIZE; f_ID++)
			{
				node_param_sum[f_ID] += node_param[f_ID];
			}
			for(f_ID=0; f_ID < TRANSIT_VEC_SIZE; f_ID++)
			{
				transit_param_sum[f_ID] += transit_param[f_ID];
			}
			if(MARKOV_ORDER == SECOND)
			{
				for(f_ID=0; f_ID < TRINODE_VEC_SIZE; f_ID++)
				{
					trinode_param_sum[f_ID] += trinode_param[f_ID];
				}
			}
			
			delete crf;
			delete [] label_predicts;
		}

		finish = clock();
		cout << "\titer " << iter+1 << "\terror rate " << err*100/(SEQ_NO) << "%" << 
					" time: " << (double)(finish-start)/CLOCKS_PER_SEC << endl;

		if(!err || (iter > 0 && pre_err < err)) break;
		pre_err = err;
	}

	//-- averaging over old params ----
	for(f_ID=0; f_ID < NODE_VEC_SIZE; f_ID++)
	{
		node_param[f_ID] = node_param_sum[f_ID]/update_no;
	}
	for(f_ID=0; f_ID < TRANSIT_VEC_SIZE; f_ID++)
	{
		transit_param[f_ID] = transit_param_sum[f_ID]/update_no;
	}
	if(MARKOV_ORDER == SECOND)
	{
		for(f_ID=0; f_ID < TRINODE_VEC_SIZE; f_ID++)
		{
			trinode_param[f_ID] = trinode_param_sum[f_ID]/update_no;
		}
	}

	delete [] node_param_sum;
	delete [] transit_param_sum;
	if(trinode_param_sum)
	{
		delete [] trinode_param_sum;
	}

	this->saveParam(param_file);
}

/*
	the training phase using simple online stochastic gradient
	of the CRF
*/
void SeqClassifier::trainOnline(int nIterations, double learning_rate, bool init_param, bool save_param, double stdev)
{
	clock_t start=clock(),finish=0;

	int seq_i,seq_ix,f, iter;
	
	//--- training parameters -----------

	int seq_len;
	double ll=0, pre_ll=0;

	//initialise parameters
	if(!PARAM_INITED)
	{
		this->initParam();
	}

	if(init_param)
	{
		this->loadParam(param_file);
	}

	double *node_grad = new double[NODE_VEC_SIZE];

	double *transit_grad = NULL;
	transit_grad = new double[TRANSIT_VEC_SIZE];

	double *trinode_grad = NULL;
	if(MARKOV_ORDER == SECOND)
	{
		trinode_grad = new double[TRINODE_VEC_SIZE];
	}

	//-------- main training loops ---------------------
	//a simple online learning strategy
	int update_no=0;
	for(iter=0; iter < nIterations; iter++)
	{
		ll=0;
 
		for(seq_ix=0; seq_ix < SEQ_NO; seq_ix++)
		{
			seq_i = seq_ix;

			feature->setSeqIndex(seq_i);
			seq_len = feature->getSeqLen(seq_i);

			if(seq_len > 1)
			{
				SeqCRF *crf = new SeqCRF(feature,seq_len,LABEL_SIZE, OB_F_SIZE,MARKOV_ORDER, NODE_FEATURE, TRANSIT_FEATURE);

				crf->setLabel(label_all->getLabels(seq_i));
				if(MARKOV_ORDER == FIRST)
				{
					crf->setParam(node_param,transit_param);
					//compute the gradient
					ll += crf->getGrad(node_grad,transit_grad);
					//ll += crf->getGradFull(node_grad,transit_grad);
				}else if(MARKOV_ORDER == SECOND)
				{
					crf->setParam(node_param,transit_param, trinode_param);
					ll += crf->getGrad(node_grad,transit_grad,trinode_grad);
					//ll += crf->getGradFull(node_grad,transit_grad,trinode_grad);
				}

				for(f=0; f < NODE_VEC_SIZE; f++)
				{
					ll -= node_param[f]*node_param[f]/(2*SEQ_NO*stdev*stdev);
					node_param[f] += learning_rate*(node_grad[f] - 
									node_param[f]/(SEQ_NO*stdev*stdev));
				}
				for(f=0; f < TRANSIT_VEC_SIZE; f++)
				{
					ll -= transit_param[f]*transit_param[f]/(2*SEQ_NO*stdev*stdev);
					transit_param[f] += learning_rate*(transit_grad[f] - 
								transit_param[f]/(SEQ_NO*stdev*stdev));
				}
				if(MARKOV_ORDER == SECOND)
				{
					for(f=0; f < TRINODE_VEC_SIZE; f++)
					{
						ll -= trinode_param[f]*trinode_param[f]/(2*SEQ_NO*stdev*stdev);
						trinode_param[f] += learning_rate*(trinode_grad[f] - 
									trinode_param[f]/(SEQ_NO*stdev*stdev));
					}
				}
				delete crf;
			}
		}

		finish = clock();
		cout << "\titer " << iter+1 << "\tlog(ll) " << ll/(SEQ_NO) << 
					" time: " << (double)(finish-start)/CLOCKS_PER_SEC << endl;

		if(iter > 0 && pre_ll > ll) break;
		pre_ll = ll;
	}

	delete [] node_grad;
	delete [] transit_grad;
	if(trinode_grad)
	{
		delete [] trinode_grad;
	}

	this->saveParam(param_file);
}

/*
	the prediction phase
*/
void SeqClassifier::predictLabels(Evaluator *eval)
{
	int seq_i, seq_len;

	if(!PARAM_INITED)
	{
		this->initParam();
	}
	this->loadParam(param_file);

	for(seq_i=0; seq_i < SEQ_NO; seq_i++)
	{
		seq_len = feature->getSeqLen(seq_i);

		SeqCRF *crf = new SeqCRF(feature,seq_len,LABEL_SIZE,OB_F_SIZE,MARKOV_ORDER, NODE_FEATURE, TRANSIT_FEATURE);

		feature->setSeqIndex(seq_i);
		if(MARKOV_ORDER == FIRST)
		{
			crf->setParam(node_param,transit_param);
		}else if(MARKOV_ORDER == SECOND)
		{
			crf->setParam(node_param,transit_param,trinode_param);
		}
		//prediction
		int *label_predicts = new int[seq_len];
		crf->getMAP(label_predicts);

		eval->setLabels(seq_i,label_predicts,seq_len);
		delete crf;
		delete [] label_predicts;
	}
}

void SeqClassifier::initParam()
{
	NODE_VEC_SIZE = LABEL_SIZE;
	if(NODE_FEATURE)
	{
		NODE_VEC_SIZE = LABEL_SIZE*OB_F_SIZE;
	}

	TRANSIT_VEC_SIZE = LABEL_SIZE*LABEL_SIZE;
	if(TRANSIT_FEATURE)
	{
		TRANSIT_VEC_SIZE = LABEL_SIZE*LABEL_SIZE*OB_F_SIZE;
	}

	node_param = new double[NODE_VEC_SIZE];
	zeros(node_param,NODE_VEC_SIZE);

	transit_param = new double[TRANSIT_VEC_SIZE];
	zeros(transit_param,TRANSIT_VEC_SIZE);

	TRINODE_VEC_SIZE  =  0;
	if(MARKOV_ORDER == SECOND)
	{
		TRINODE_VEC_SIZE = LABEL_SIZE*LABEL_SIZE*LABEL_SIZE;
		trinode_param = new double[TRINODE_VEC_SIZE];
		zeros(trinode_param,TRINODE_VEC_SIZE);
	}

	PARAM_VEC_SIZE = NODE_VEC_SIZE + TRANSIT_VEC_SIZE + TRINODE_VEC_SIZE;
	
	PARAM_INITED = true;
}

/*
	write parameters to file:
     the first line is for node parameter
     the second line is for the transition parameter
     the third line is for the second-order parameter
*/

void SeqClassifier::saveParam(char *file_name)
{
	int f;
	FILE *fp = fopen(file_name,"w");

	for(f=0; f < NODE_VEC_SIZE; f++)
	{
		fprintf(fp,"%.5f ", node_param[f]);
	}
	fprintf(fp,"\n");
	
	for(f=0; f < TRANSIT_VEC_SIZE; f++)
	{
		fprintf(fp,"%.5f ", transit_param[f]);
	}
	fprintf(fp,"\n");
	
	if(MARKOV_ORDER == SECOND)
	{
		for(f=0; f < TRINODE_VEC_SIZE; f++)
		{
			fprintf(fp,"%.5f ", trinode_param[f]);
		}
		fprintf(fp,"\n");
	}

	fclose(fp);
}

// load parameters from file, see saveParam() for format
void SeqClassifier::loadParam(char *file_name)
{
	ifstream input;

	int line_len;

	if(MARKOV_ORDER == FIRST)
	{
		line_len = (NODE_VEC_SIZE > TRANSIT_VEC_SIZE)? NODE_VEC_SIZE : TRANSIT_VEC_SIZE;
	}else if(MARKOV_ORDER == SECOND)
	{
		line_len = (NODE_VEC_SIZE > TRANSIT_VEC_SIZE)? NODE_VEC_SIZE : TRANSIT_VEC_SIZE;
		line_len = (line_len > TRINODE_VEC_SIZE)? line_len : TRINODE_VEC_SIZE;
	}
	line_len = line_len*10; //see saveParam() for the formatting

	char *line = new char[line_len]; 
	char token[20];
	int i,j;
	
	input.open(file_name);

	//check for wrong input file
	if (!input)
	{
		cout << "\n";
		cout << "SeqClassifier::loadParam() - Fatal error!\n";
		cout << "Could not read observation file: \"" << file_name << "\"\n";
		exit(1);
	}

	//-------- extract the field numerical values ---------------
	int line_no=0,f;
	while (input.getline(line,line_len))
	{
		line_no++;
		i=0;j=0;f = 0;
		while(line[i] != '\0')
		{
			if(line[i] == ' ')
			{ //end of label
				token[j] = '\0';

				if(line_no==1)
				{
					node_param[f++] = (double)atof(token);
				}else if(line_no==2)
				{
					transit_param[f++] = (double)atof(token);
				}else if(line_no == 3 && MARKOV_ORDER == SECOND)
				{
					trinode_param[f++] = (double)atof(token);
				}

				j=0;
			}else{

				token[j] = line[i];
				j++;
			}

			i++;
		}
	}

	input.clear();
	input.close();
}

