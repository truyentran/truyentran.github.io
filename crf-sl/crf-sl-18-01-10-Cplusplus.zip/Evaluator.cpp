/*
	CRF-SL: Conditional Random Fields for Sequential Labelling

	Copyright (C) 2006-2008 Tran The Truyen <thetruyen.tran@postgrad.curtin.edu.au>
	This is free software with ABSOLUTELY NO WARRANTY.
  
	This library is free software; you can redistribute it and/or
	modify it under the terms of the GNU Lesser General Public
	License as published by the Free Software Foundation; either
	version 2.1 of the License, or (at your option) any later version.
  
	This library is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
	Lesser General Public License for more details.
  
	You should have received a copy of the GNU Lesser General Public
	License along with this library; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/


#include <iostream>
#include <stdio.h>

#include "Evaluator.h"
#include "utility.h"

using namespace std;

Evaluator::Evaluator(int label_size)
{
	LABEL_SIZE = label_size;

	true_label_all = NULL;
	predict_label_all = NULL;
}

Evaluator::~Evaluator()
{
	if(true_label_all)
	{
		delete true_label_all;
	}
	if(predict_label_all)
	{
		delete predict_label_all;
	}
}

/*
	Count a match only if the two segments match (start & end positions + labels)
*/
void Evaluator::reportSegmentWise()
{
	int true_start, true_end, predict_start, predict_end;
	int t,sq,label_index, seq_len;
	bool good_true_start, good_predict_start;
	int predict_phrase = 0, true_phrase=0, match_phrase=0,
			all_predict_phrase=0, all_true_phrase=0;
	int bad_true_chunk=0, bad_predict_chunk=0;
	int *true_labels, *predict_labels;

	for(sq=0; sq < SEQ_NO; sq++)
	{
		true_start=1;
		predict_start=1;
		good_true_start = false;
		good_predict_start = false;

		true_labels = true_label_all->getLabels(sq);
		predict_labels = predict_label_all->getLabels(sq);

		seq_len = true_label_all->getSeqLen(sq);

		for(t=1; t <= seq_len; t++)
		{
			label_index = t-1;

			//--- the prediction ---
			if(predict_labels[label_index] ==1)
			{ //begining of chunk
				predict_start = t;
				good_predict_start = true;
			}else if(t > 1 && predict_labels[label_index] == 2
				&& predict_labels[label_index-1] == 3)
			{ //error
				good_predict_start = false;
				bad_predict_chunk++;
			}

			if(good_predict_start)
			{
				if(predict_labels[label_index] != 3 &&
					(t == seq_len || predict_labels[label_index+1] != 2))
				{//this is the end of the chunk
					predict_end = t;
					predict_phrase++;
				}
			}

			if(t == seq_len ||
				(predict_labels[label_index]==1 && predict_labels[label_index+1]==1) ||
				(predict_labels[label_index] != predict_labels[label_index+1]
						&&!(	predict_labels[label_index]==1 &&
								predict_labels[label_index+1]==2
							)
				)
			   )
			{
				all_predict_phrase++;
			}

			//--- the groundtruth-------
			if(true_labels[label_index] ==1)
			{ //begining of chunk
				true_start = t;
				good_true_start = true;
			}else if(t > 1 && true_labels[label_index] == 2
				&& true_labels[label_index-1] == 3)
			{ //error
				good_true_start = false;
				bad_true_chunk++;
			}

			if(good_true_start)
			{
				if(true_labels[label_index] != 3 &&
					(t == seq_len || true_labels[label_index+1] != 2))
				{
					//this is the end of the chunk
					true_end = t;
					true_phrase++;
		
					if(true_start == predict_start && 
						true_end == predict_end && 
						true_labels[label_index] == predict_labels[label_index])
					{
						match_phrase++;
					}
				}
			}

			if(t == seq_len ||
				(true_labels[label_index]==1 && true_labels[label_index+1]==1) ||
				(true_labels[label_index] != true_labels[label_index+1]
					&&	!(true_labels[label_index]==1
							&& true_labels[label_index+1]==2
						 )
				 )
			   )
			{
				all_true_phrase++;
			}
		}

	}
 	
	double recall = (true_phrase)? (double)(match_phrase*100.0/true_phrase) : 0;
	double precision = (predict_phrase) ? (double)(match_phrase*100.0/predict_phrase) : 0;
	double F1 = (recall+precision)? 2*recall*precision/(recall+precision) : 0;

	cout << "Noun-phrase chunking:\n";
	
	cout << "\tAll groundtruth phrases:\t" << all_true_phrase << endl;
	cout << "\tGroundtruth noun-phrases:\t" << true_phrase << ", or " << true_phrase*100.0/all_true_phrase << "%" << endl;

	cout << "\tAll predicted phrases:\t" << all_predict_phrase << endl;
	cout << "\tPredicted noun-phrases:\t" << predict_phrase << ", or " << predict_phrase*100.0/all_predict_phrase << "%" << endl;

	cout << "\tRecall:\t" << recall << "%" << endl;
	cout << "\tPrecision:\t" << precision << "%" << endl;
	cout << "\tF1:\t" << F1 << "%" << endl;

	cout << "Bad groundtruth chunks:\t" << bad_true_chunk*100.0/(1e-16+true_phrase) << "%" << endl;
	cout << "Bad predicted chunks:\t" << bad_predict_chunk*100.0/(1e-16+predict_phrase) << "%" << endl;
}

void Evaluator::setLabels(int sq, int *predict_label, int seq_len)
{
	if(!predict_label_all)
	{
		predict_label_all = new Label(SEQ_NO);

	}
	predict_label_all->setLabels(sq,predict_label,seq_len);

	LABEL_TAGS_INITED = true;

}

/*
	Count a match if the two labels match
*/
void Evaluator::reportLabelWise()
{
	int t, sq,label;
	int *true_labels, *predict_labels;

	double *true_positive = new double[LABEL_SIZE];
	double *true_negative = new double[LABEL_SIZE];
	double *false_positive = new double[LABEL_SIZE];
	double *false_negative = new double[LABEL_SIZE];

	zeros(true_positive,LABEL_SIZE);
	zeros(true_negative,LABEL_SIZE);
	zeros(false_positive,LABEL_SIZE);
	zeros(false_negative,LABEL_SIZE);

	double accuracy = 0;
	double *recall = new double[LABEL_SIZE];
	double *precision = new double[LABEL_SIZE];
	double *f_score = new double [LABEL_SIZE];
	double macro_F1 = 0;
	double micro_F1 = 0;

	int data_point = 0, label_index, seq_len;
	for(sq=0; sq < SEQ_NO; sq++)
	{
		true_labels = true_label_all->getLabels(sq);
		predict_labels = predict_label_all->getLabels(sq);
		seq_len = true_label_all->getSeqLen(sq);

		for(t=1; t <= seq_len; t++)
		{
			data_point++;
			label_index = t-1;

			for(label = 1; label <= LABEL_SIZE; label++)
			{

				if(true_labels[label_index] == label && predict_labels[label_index] == label)
				{
					accuracy++;
					true_positive[label-1] ++; 
				}else if(true_labels[label_index] != label && predict_labels[label_index] != label)
				{
					true_negative[label-1] ++; 
				}else if(true_labels[label_index] == label && predict_labels[label_index] != label)
				{
					false_positive[label-1] ++; 
				}else //if(true_labels[label_index] != label && predict_labels[label_index] == label)
				{
					false_negative[label-1] ++; 
				}
			}
		}
	}

    accuracy *= (double)100.0/data_point;
	macro_F1 = 0;
	for(label = 1; label <= LABEL_SIZE; label++)
	{
		recall[label-1] = 100*true_positive[label-1]/((double)1e-16+true_positive[label-1] + false_positive[label-1]);
		precision[label-1] = 100*true_positive[label-1]/((double)1e-16+true_positive[label-1] + false_negative[label-1]);
		f_score[label-1] = 2*recall[label-1]*precision[label-1]/((double)1e-16+recall[label-1] + precision[label-1]);
		macro_F1 += f_score[label-1];

	}

	macro_F1 *= (double)1.0/LABEL_SIZE;

	//-- print out --------------------------------
	printf("State\tRecall\tPrec\tF1\n");
	printf("-----\t------\t----\t--\n");
	for(label = 1; label <= LABEL_SIZE; label++)
	{
		printf("%d\t%6.2f\t%6.2f\t%6.2f\n",label,recall[label-1],precision[label-1],f_score[label-1]);
	}

	printf("Macro F1:\t%6.2f\n",macro_F1);
	printf("Acuracy:\t%6.2f\n",accuracy);

}

void Evaluator::readTestLabels(char *state_file)
{
	true_label_all = new Label();

	true_label_all->readLabels(state_file);

	SEQ_NO = true_label_all->getSeqNo();
}

