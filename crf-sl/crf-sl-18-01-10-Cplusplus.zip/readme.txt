
** LAST UPDATE ******
-- 18/1/10 ----
Fixing some file reading bugs - handle long sequences and trailing characters in features and label files
Modifying the code to work with Visual C++ 2008

-- 16/4/08 ----
Bug fixing for L-BFGS. This is due to the imprecision of FLOAT numbers. 
Convert all to double solves the problem. But this requires more memory!

-- 14/4/08 ----
First and second-order sequential CRFs are implemented.
The second-order potentials make use of only indicator features for fast processing.


** RUN EXPERIMENTS ******
Please enter parameters in the "run.conf" file.
We need to prepare two input files: the feature file and
the label file for training and testing.


++ FEATURE FILE FORMAT +++
	The feature file implement a sparse representation in that
	only non-zeros data features are included. Each
	line is a sparse feature vector of the form:

		f_val1:f_ID1 f_val2:f_ID2 f_val3:f_ID3 ...

		where
		
			f_val	: value of the feature
			f_ID	: the ID of data feature.
	

	+Each continuing sequence of lines is an observational sequence
	+Sequences are separated by blank lines

++ LABEL FILE FORMAT +++
	Each line is a sequence of labels, separated by an empty space. Sequences
	are separated by an empty line.

	Line format:
		1 2 1 -1 2 1
		
		2 3 -1 -1 0 2
	The value of -1 means the label is missing.

** TEST DATA **********
In the directory "data/conll2000" has the pre-computed features
for the CoNLL-2000 shared task. There are two training data
sets: the full-set and the small-set (about 10% of the full-set).


