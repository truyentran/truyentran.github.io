/*
	CRF-SL: Conditional Random Fields for Sequential Labelling

	Copyright (C) 2006-2008 Tran The Truyen <thetruyen.tran@postgrad.curtin.edu.au>
	This is free software with ABSOLUTELY NO WARRANTY.
  
	This library is free software; you can redistribute it and/or
	modify it under the terms of the GNU Lesser General Public
	License as published by the Free Software Foundation; either
	version 2.1 of the License, or (at your option) any later version.
  
	This library is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
	Lesser General Public License for more details.
  
	You should have received a copy of the GNU Lesser General Public
	License along with this library; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/


#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include "SeqFeature.h"
#include "utility.h"

using namespace std;


SeqFeature::SeqFeature()
{
	this->init();
}

SeqFeature::SeqFeature(int label_size)
{
	LABEL_SIZE = label_size;

	this->init();
}
 
void SeqFeature::init()
{
	feature_sq = NULL;
	DATABASE_LOADED = false;

	curr_t = -1;
	curr_sq		= -1;
	curr_label		= -1;

	node_f_index = 0;

	NODE_NO = 0;

	SEQ_LEN_INITED = false;
}

SeqFeature::~SeqFeature()
{
	if(DATABASE_LOADED)
	{
		this->clean();
	}

	if(SEQ_LEN_INITED)
	{
		delete [] seq_lenx;
	}
}

/*
	return 1 if next feature is found
	and 0 otherwise
*/
int SeqFeature::getNextDataPattern(int t, double *f, int *f_ID, bool restart)
{
	if(t==0)
	{
		cerr << "time must be positive" << endl;
		exit(1);
	}

	int node_index = seq_start_index[curr_sq]+t-1;

	if(restart || t != curr_t)
	{
		curr_t = t;

		node_f_index = 0;
	}

	if(node_f_index == feature_all[node_index].len)
	{ //run out of features at this node and this label
		return 0;
	}

	*f = feature_all[node_index].val[node_f_index];
	*f_ID = feature_all[node_index].index[node_f_index];

	node_f_index++;

	return 1;
}


/*
	Read data observation file
	
	Format of each line:
		f_val1:f_ID1 f_val2:f_ID2 f_val3:f_ID3 ...

	f_val	: value of the feature
	f_ID	: the ID of the FINAL feature set, missing features are not included

	+Each continuing sequence of lines is an observational sequence
	+Sequences are separated by blank lines
*/
int SeqFeature::readDataPatternFile(char *file_name)
{ 
	ifstream input;
	char line[10240];
	char token[20];
	int i,j,len,val_index,node_index;
	int sq=0;
	
	input.open(file_name);

	//check for wrong input file
	if (!input)
	{
		cout << "\n";
		cout << "SeqFeature::readObs() - Fatal error!\n";
		cout << "Could not read observation file: \"" << file_name << "\"\n";
		return 0;
	}

	//------- compute the size of the feature data base --------
	SEQ_NO=0;
	NODE_NO=0;
	while (input.getline(line,sizeof(line)) && !(input.eof()))
	{
		if (line[0] == '#')
		{ //this is a comment, ignore
			continue;
		}

		if(s_len_trim(line) == 0)
		{ //this is a new sequence
			SEQ_NO++;
		}

		NODE_NO++;
	}
	SEQ_NO++;

	input.clear();
	input.close();
	input.open(file_name);

	//sequence lengths
	seq_lenx = new int[SEQ_NO];
	SEQ_LEN_INITED = true;

	//initialise the feature data base
	if(DATABASE_LOADED)
	{
		this->clean();
	}
	feature_all = new NodeFeature[NODE_NO];
	seq_start_index = new int[SEQ_NO];
	DATABASE_LOADED = true;


	//-------- extract the field numerical values ---------------
	node_index = 0; //this is the index of all nodes in the data base
	bool new_sq = false;
	int f_index;
	seq_start_index[0] = 0;
	sq=0;
	seq_lenx[sq] = 0;

	OB_F_MAX = 1; 	//size to be detected later when scanning the feature file
	
	while (input.getline(line,sizeof(line)) && !(input.eof()))
	{
		if (line[0] == '#')
		{ //this is a comment, ignore
			continue;
		}

		if(s_len_trim(line) == 0)
		{ //this is a gap between sequences, count only once
			if(!new_sq)
			{
				new_sq = true;

				feature_all[node_index].len = 0;
				node_index++;

				sq++;
				seq_start_index[sq] = node_index;
				seq_lenx[sq] = 0;
			}

			continue;
		}else{
			new_sq = false;
			seq_lenx[sq]++;
		}

		//get the number of activated features for this node
		i=0;
		len = 0;
		while(line[i] != '\0')
		{
			if((line[i] == ' ' || line[i] == '\t') && line[i+1] != '\0')
			{
				len++;
			}
			i++;
		}
		len++;

		feature_all[node_index].len = len;
		feature_all[node_index].val = new double[len];
		feature_all[node_index].index = new int[len];
		feature_all[node_index].label = NULL;
		feature_all[node_index].label_start = NULL;

		//get the feature values
		val_index = 0;
		i=0;
		j=0;
		while(line[i] != '\0')
		{
			if(line[i] == ':')
			{ 
				token[j] = '\0';
				
				//end of feature value
				feature_all[node_index].val[val_index] = (double)atof(token);

				j=0;
			}else if((line[i] == ' ' || line[i] == '\t') && line[i+1] != '\0')
			{//end of feature index
				token[j] = '\0';
				f_index = atoi(token);
				feature_all[node_index].index[val_index] = f_index;

				if(OB_F_MAX < f_index+1)
				{
					OB_F_MAX = f_index+1;
				}

				val_index++;

				j=0;
			}else{

				token[j] = line[i];
				j++;
			}

			i++;
		}
		//at the end of the line, extract the last feature index
		token[j] = '\0';
		f_index = atoi(token);
		feature_all[node_index].index[val_index] = f_index;
		if(OB_F_MAX < f_index+1)
		{
			OB_F_MAX = f_index+1;
		}


		node_index++;
	}

	input.clear();
	input.close();
 
	return 1;
}

/*
	see readDataPattern() for formatting details
	mostly for testing purposes
*/
void SeqFeature::writeDataPatternFile(char *file_name)
{
	int flag;

	ofstream output;

	output.open(file_name);

	int seq_i,t, node_index,f_ID;
	double f;
	for(seq_i=0; seq_i < SEQ_NO; seq_i++)
	{
		this->setSeqIndex(seq_i);

		for(t=1; t <= seq_lenx[seq_i]; t++)
		{
			node_index = seq_start_index[curr_sq]+t-1;

			curr_sq = seq_i;
			flag = this->getNextDataPattern(t,&f,&f_ID,true);
			output << f << ":" << f_ID;
			while(1)
			{
				flag = this->getNextDataPattern(t,&f,&f_ID,false);
				if(flag)
				{
					output << " " << f << ":" << f_ID;
				}else
				{
					break;
				}
			}
			output << endl;
		}

		if(seq_i < SEQ_NO-1)
		{
			output << endl;
		}

	}

	output.clear();
	output.close();
}

//clean up space of stored features
void SeqFeature::clean()
{
	int node_i = 0;

	//clean up the database
	while(node_i < NODE_NO)
	{
		if(feature_all[node_i].len !=0 )
		{
			delete [] feature_all[node_i].val;
			delete [] feature_all[node_i].index;
			if(feature_all[node_i].label)
			{
				delete [] feature_all[node_i].label;
			}
			if(feature_all[node_i].label_start)
			{
				delete [] feature_all[node_i].label_start;
			}
		}

		node_i++;
	}

	delete [] feature_all;
	delete [] seq_start_index;
}

int SeqFeature::getNodeNo()
{
	return NODE_NO;
}

void SeqFeature::setLabelSize(int label_size)
{
	LABEL_SIZE = label_size;
}


int SeqFeature::getSeqLen(int sq)
{
	return seq_lenx[sq];
}


void SeqFeature::setSeqIndex(int seq_i)
{
	curr_sq = seq_i;
}


void SeqFeature::setSeqLens(int *lens, int seq_no)
{
	seq_lens = lens;

	SEQ_NO = seq_no;
}

int SeqFeature::getObsFeatureSize()
{
	return OB_F_MAX;
}

int SeqFeature::getSeqNo()
{
	return SEQ_NO;
}

void SeqFeature::setCurrLabel(int label)
{
	curr_label = label;
}