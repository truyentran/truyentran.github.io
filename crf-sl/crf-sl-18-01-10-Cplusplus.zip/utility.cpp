/*
	CRF-SL: Conditional Random Fields for Sequential Labelling

	Copyright (C) 2006-2008 Tran The Truyen <thetruyen.tran@postgrad.curtin.edu.au>
	This is free software with ABSOLUTELY NO WARRANTY.
  
	This library is free software; you can redistribute it and/or
	modify it under the terms of the GNU Lesser General Public
	License as published by the Free Software Foundation; either
	version 2.1 of the License, or (at your option) any later version.
  
	This library is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
	Lesser General Public License for more details.
  
	You should have received a copy of the GNU Lesser General Public
	License along with this library; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <string.h>
#include <math.h>
#include <stdlib.h>

#include "utility.h"

//--------- function implementations ------------------

//---
void zeros(int *vector, int len){init_vector(vector,len,0);}
void zeros(float *vector, int len){init_vector(vector,len,0);}
void zeros(double *vector, int len){init_vector(vector,len,0);}

//---
void ones(int *vector, int len){init_vector(vector,len,1);}
void ones(float *vector, int len){init_vector(vector,len,1);}
void ones(double *vector, int len){init_vector(vector,len,1);}


//---
void init_vector(int *vector, int len, int val)
{
	int i;
	for(i=0; i < len; i++)
	{
		vector[i] = val;
	}
}

void init_vector(float *vector, int len, float val)
{
	int i;
	for(i=0; i < len; i++)
	{
		vector[i] = val;
	}
}

void init_vector(double *vector, int len, double val)
{
	int i;
	for(i=0; i < len; i++)
	{
		vector[i] = val;
	}
}

//---
void rand_vector(float *vector, int len)
{
	int i;
	for(i=0; i < len; i++)
	{
		vector[i] = ((float)rand())/RAND_MAX;
	}
}
void rand_vector(double *vector, int len)
{
	int i;
	for(i=0; i < len; i++)
	{
		vector[i] = (rand())/RAND_MAX;
	}
}
//---

void rand_vector(float *vector, float scale, int len)
{
	int i;
	for(i=0; i < len; i++)
	{
		vector[i] = (scale*rand())/RAND_MAX;
	}
}
void rand_vector(double *vector, double scale, int len)
{
	int i;
	for(i=0; i < len; i++)
	{
		vector[i] = (scale*rand())/RAND_MAX;
	}
}

//---
void copy_vector(int *from, int *to, int len)
{
	int i;
	for(i=0; i < len; i++)
	{
		to[i] = from[i];
	}
}
void copy_vector(float *from, float *to, int len)
{
	int i;
	for(i=0; i < len; i++)
	{
		to[i] = from[i];
	}
}
void copy_vector(double *from, double *to, int len)
{
	int i;
	for(i=0; i < len; i++)
	{
		to[i] = from[i];
	}
}

//---
void add_vector(float *v1, float *v2, float *sum, int len)
{
	int i;
	for(i=0; i < len; i++)
	{
		sum[i] = v1[i] + v2[i];
	}
}
void add_vector(double *v1, double *v2, double *sum, int len)
{
	int i;
	for(i=0; i < len; i++)
	{
		sum[i] = v1[i] + v2[i];
	}
}
//---

void add_vector(float *v, float *more, int len)
{
	int i;
	for(i=0; i < len; i++)
	{
		v[i] = v[i] + more[i];
	}
}
void add_vector(double *v, double *more, int len)
{
	int i;
	for(i=0; i < len; i++)
	{
		v[i] = v[i] + more[i];
	}
}
//---

void add_scalar(float *v, float c, int len)
{
	int i;
	for(i=0; i < len; i++)
	{
		v[i] = v[i] + c;
	}
}
void add_scalar(double *v, double c, int len)
{
	int i;
	for(i=0; i < len; i++)
	{
		v[i] = v[i] + c;
	}
}
//---

void multi_scalar(float *v, float c, int len)
{
	int i;
	for(i=0; i < len; i++)
	{
		v[i] = c*v[i];
	}

}
void multi_scalar(double *v, double c, int len)
{
	int i;
	for(i=0; i < len; i++)
	{
		v[i] = c*v[i];
	}

}

//---
void div_scalar(float *v, float c, int len)
{
	int i;
	for(i=0; i < len; i++)
	{
		v[i] = v[i]/c;
	}

}
void div_scalar(double *v, double c, int len)
{
	int i;
	for(i=0; i < len; i++)
	{
		v[i] = v[i]/c;
	}

}

//---
void log_vector(float *v, int len)
{
	int i;
	for(i=0; i < len; i++)
	{
		v[i] = (float)log(v[i]);
	}

}
void log_vector(double *v, int len)
{
	int i;
	for(i=0; i < len; i++)
	{
		v[i] = log(v[i]);
	}

}

//---
void exp_vector(float *v, int len)
{
	int i;
	for(i=0; i < len; i++)
	{
		v[i] = (float)exp(v[i]);
	}

}
void exp_vector(double *v, int len)
{
	int i;
	for(i=0; i < len; i++)
	{
		v[i] = exp(v[i]);
	}

}

//---
void substract_vector(float *from, float *less, float *diff, int len)
{
	int i;
	for(i=0; i < len; i++)
	{
		diff[i] = from[i] - less[i];
	}
}
void substract_vector(double *from, double *less, double *diff, int len)
{
	int i;
	for(i=0; i < len; i++)
	{
		diff[i] = from[i] - less[i];
	}
}

//---
void substract_vector(float *from, float *less, int len)
{
	int i;
	for(i=0; i < len; i++)
	{
		from[i] = from[i] - less[i];
	}
}
void substract_vector(double *from, double *less, int len)
{
	int i;
	for(i=0; i < len; i++)
	{
		from[i] = from[i] - less[i];
	}
}

//---
float inner_prod(float *v1, float *v2, int len)
{
	int i;
	float prod = 0;
	for(i=0; i < len; i++)
	{
		prod += v1[i]*v2[i];
	}

	return prod;
}
double inner_prod(double *v1, double *v2, int len)
{
	int i;
	double prod = 0;
	for(i=0; i < len; i++)
	{
		prod += v1[i]*v2[i];
	}

	return prod;
}

//---
int sum_vector(int *v, int len)
{
	int i;
	int sum = 0;
	for(i=0; i < len; i++)
	{
		sum += v[i];
	}

	return sum;
}

float sum_vector(float *v, int len)
{
	int i;
	float sum = 0;
	for(i=0; i < len; i++)
	{
		sum += v[i];
	}

	return sum;
}
double sum_vector(double *v, int len)
{
	int i;
	double sum = 0;
	for(i=0; i < len; i++)
	{
		sum += v[i];
	}

	return sum;
}

//---
float normalise(float *v, int len)
{
	int i;
	float sum = 0;
	for(i=0; i < len; i++)
	{
		sum += v[i];
	}

	if(sum==0)
	{
		return 0;
	}

	for(i=0; i < len; i++)
	{
		v[i] = v[i]/sum;
	}

	return sum;
}
double normalise(double *v, int len)
{
	int i;
	double sum = 0;
	for(i=0; i < len; i++)
	{
		sum += v[i];
	}

	if(sum==0)
	{
		return 0;
	}

	for(i=0; i < len; i++)
	{
		v[i] = v[i]/sum;
	}

	return sum;
}

//---
int* abs_vector(int *v, int len)
{
	int i;
	for(i=0; i < len; i++)
	{
		v[i] = abs(v[i]);
	}

	return v;
}
float* abs_vector(float *v, int len)
{
	int i;
	for(i=0; i < len; i++)
	{
		v[i] = (float)fabs(v[i]);
	}

	return v;
}
double* abs_vector(double *v, int len)
{
	int i;
	for(i=0; i < len; i++)
	{
		v[i] = fabs(v[i]);
	}

	return v;
}

//-----
int max_vector(int *v, int len)
{
	int i;
	int max=v[0];
	for(i=1; i < len; i++)
	{
		if(max < v[i])
		{
			max = v[i];
		}
	}

	return max;
}
float max_vector(float *v, int len)
{
	int i;
	float max=v[0];
	for(i=1; i < len; i++)
	{
		if(max < v[i])
		{
			max = v[i];
		}
	}

	return max;
}
double max_vector(double *v, int len)
{
	int i;
	double max=v[0];
	for(i=1; i < len; i++)
	{
		if(max < v[i])
		{
			max = v[i];
		}
	}

	return max;
}

//---
int min_vector(int *v, int len)
{
	int i;
	int min=v[0];
	for(i=1; i < len; i++)
	{
		if(min > v[i])
		{
			min = v[i];
		}
	}

	return min;
}
float min_vector(float *v, int len)
{
	int i;
	float min=v[0];
	for(i=1; i < len; i++)
	{
		if(min > v[i])
		{
			min = v[i];
		}
	}

	return min;
}
double min_vector(double *v, int len)
{
	int i;
	double min=v[0];
	for(i=1; i < len; i++)
	{
		if(min > v[i])
		{
			min = v[i];
		}
	}

	return min;
}

//----
int* join(int *head, int *tail, int *all, int head_len, int tail_len)
{
	int i;
	for(i=0; i < head_len; i++)
	{
		all[i] = head[i];
	}
	for(; i < head_len+tail_len; i++)
	{
		all[i] = tail[i-head_len];
	}

	return all;
}
float* join(float *head, float *tail, float *all, int head_len, int tail_len)
{
	int i;
	for(i=0; i < head_len; i++)
	{
		all[i] = head[i];
	}
	for(; i < head_len+tail_len; i++)
	{
		all[i] = tail[i-head_len];
	}

	return all;
}
double* join(double *head, double *tail, double *all, int head_len, int tail_len)
{
	int i;
	for(i=0; i < head_len; i++)
	{
		all[i] = head[i];
	}
	for(; i < head_len+tail_len; i++)
	{
		all[i] = tail[i-head_len];
	}

	return all;
}

//---
void extract(int *sub, int *full, int sub_start, int sub_len)
{
	int i;
	for(i=sub_start; i < sub_start+sub_len; i++)
	{
		sub[i-sub_start] = full[i];
	}
}
void extract(float *sub, float *full, int sub_start, int sub_len)
{
	int i;
	for(i=sub_start; i < sub_start+sub_len; i++)
	{
		sub[i-sub_start] = full[i];
	}
}
void extract(double *sub, double *full, int sub_start, int sub_len)
{
	int i;
	for(i=sub_start; i < sub_start+sub_len; i++)
	{
		sub[i-sub_start] = full[i];
	}
}

//--
void insert(int *sub, int *full, int sub_start, int sub_len)
{
	int i;
	for(i=sub_start; i < sub_start+sub_len; i++)
	{
		full[i] = sub[i-sub_start];
	}
}
void insert(float *sub, float *full, int sub_start, int sub_len)
{
	int i;
	for(i=sub_start; i < sub_start+sub_len; i++)
	{
		full[i] = sub[i-sub_start];
	}
}
void insert(double *sub, double *full, int sub_start, int sub_len)
{
	int i;
	for(i=sub_start; i < sub_start+sub_len; i++)
	{
		full[i] = sub[i-sub_start];
	}
}

//--
float distance(float *v1, float *v2, int len)
{
	int i;
	float dis=0;
	for(i=0; i < len; i++)
	{
		dis += (v1[i]-v2[i])*(v1[i]-v2[i]);
	}
	return (float)sqrt(dis);
}
double distance(double *v1, double *v2, int len)
{
	int i;
	double dis=0;
	for(i=0; i < len; i++)
	{
		dis += (v1[i]-v2[i])*(v1[i]-v2[i]);
	}
	return sqrt(dis);
}

/*
	Purpose: S_LEN_TRIM returns the length of a string to the last nonblank.
	Modified:  26 April 2003
	Author: John Burkardt
	Parameters:
		Input, char *S, a pointer to a string.
		Output, int S_LEN_TRIM, the length of the string to the last nonblank.
			If S_LEN_TRIM is 0, then the string is entirely blank.
*/
int s_len_trim ( char *s )
{
  int n;
  char *t;

  n = strlen ( s );
  t = s + strlen ( s ) - 1;

  while ( 0 < n )
  {
    if ( *t != ' ' )
    {
      return n;
    }
    t--;
    n--;
  }

  return n;
}