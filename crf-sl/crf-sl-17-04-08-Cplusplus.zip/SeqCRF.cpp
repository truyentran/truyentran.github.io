/*
	CRF-SL: Conditional Random Fields for Sequential Labelling

	Copyright (C) 2006-2008 Tran The Truyen <thetruyen.tran@postgrad.curtin.edu.au>
	This is free software with ABSOLUTELY NO WARRANTY.
  
	This library is free software; you can redistribute it and/or
	modify it under the terms of the GNU Lesser General Public
	License as published by the Free Software Foundation; either
	version 2.1 of the License, or (at your option) any later version.
  
	This library is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
	Lesser General Public License for more details.
  
	You should have received a copy of the GNU Lesser General Public
	License along with this library; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/


#include <math.h>
#include <iostream.h>
#include <stdlib.h>

#include "SeqCRF.h"
#include "utility.h"

//Some macros
#define SUM		1
#define MAX		2
#define FREE	3
#define CLAMP	4

#define node_poten(t) node_poten[t-1]
#define transit_poten(t) transit_poten[t-1]
#define trinode_poten(pre_label,label,post_label) trinode_poten[(pre_label-1)*LABEL_SIZE*LABEL_SIZE + (label-1)*LABEL_SIZE + post_label-1]

#define node_f_expect(f) node_f_expect[f]
#define transit_f_expect(pre_label,label) transit_f_expect[(pre_label-1)*LABEL_SIZE+label-1]
#define trinode_f_expect(pre_label,label,post_label) trinode_f_expect[(pre_label-1)*LABEL_SIZE*LABEL_SIZE + (label-1)*LABEL_SIZE + post_label-1]

#define node_grad(f) node_grad[f]
#define transit_grad(pre_label,label) transit_grad[(pre_label-1)*LABEL_SIZE+label-1]
#define trinode_grad(pre_label,label,post_label) trinode_grad[(pre_label-1)*LABEL_SIZE*LABEL_SIZE + (label-1)*LABEL_SIZE + post_label-1]

#define node_margin(t) node_margin[t-1]
#define transit_margin(t) transit_margin[t-1]
#define trinode_margin(t) trinode_margin[t-1]

#define forward(t) forward[t-1]
#define backward(t) backward[t-1]

#define bookkeeper(t,label) bookkeeper[(t-1)*LABEL_SIZE + label-1]

#define label_set(t) label_set[t-1]

//---------------------------------------
SeqCRF::SeqCRF(SeqFeature *ftr, int seq_len, int label_size, int ob_f_size, int order, int node_feature, int transit_feature)
{
	SEQ_LEN = seq_len;
	LABEL_SIZE = label_size;
	OB_F_SIZE = ob_f_size;
	MARKOV_ORDER = order;

	feature = ftr;

	F_EXPECT_INITED = false;
	POTEN_COMPUTED = false;
	POTEN_INITED = false;
	MARGIN_INITED = false;
	LABEL_SET_INITED = false;
	MSG_INITED = false;


	NODE_FEATURE = node_feature;
	TRANSIT_FEATURE = transit_feature;

	NODE_VEC_SIZE = LABEL_SIZE;
	if(NODE_FEATURE)
	{
		NODE_VEC_SIZE = LABEL_SIZE*OB_F_SIZE;
	}

	TRANSIT_VEC_SIZE = LABEL_SIZE*LABEL_SIZE;
	if(TRANSIT_FEATURE)
	{
		TRANSIT_VEC_SIZE = OB_F_SIZE*LABEL_SIZE*LABEL_SIZE;
	}

	TRINODE_VEC_SIZE = 0;
	if(MARKOV_ORDER == SECOND)
	{
		TRINODE_VEC_SIZE = LABEL_SIZE*LABEL_SIZE*LABEL_SIZE;
	}
	node_poten = NULL;
	transit_poten = NULL;
	trinode_poten = NULL;

	node_f_expect = NULL;
	transit_f_expect = NULL;
	trinode_f_expect = NULL;
}

SeqCRF::~SeqCRF()
{
	if(F_EXPECT_INITED)
	{
		delete [] node_f_expect;
		delete [] transit_f_expect;

		if(MARKOV_ORDER == SECOND)
		{
			delete [] trinode_f_expect;
		}
	}

	if(MARGIN_INITED)
	{
		this->clearMargin();
	}

	if(POTEN_INITED)
	{
		this->clearPoten();
	}

	if(LABEL_SET_INITED)
	{
		this->clearStSet();
	}

	if(MSG_INITED)
	{
		this->clearMsg();
	}
}

//compute the node, transit and (optionally) trinode potential functions
void SeqCRF::computePoten()
{
	int t,f_ID,pre_label,label,post_label,f_index;
	double f;
	double tmp;
	int flag;
		
	POTEN_COMPUTED = true;

	//--allocating memory--------
	if(!POTEN_INITED)
	{
		this->initPoten();
	}

	if(NODE_FEATURE)
	{
		//observation features => node potentials
		for(t=1; t <= SEQ_LEN; t++)
		{
			for(label=1; label <= LABEL_SIZE; label++)
			{
				tmp = 0;
				flag = feature->getNextDataPattern(t,&f,&f_ID,true);
				while(flag)
				{	
					tmp += f*node_param[node_f_index(label,f_ID)];
					flag = feature->getNextDataPattern(t,&f,&f_ID,false);
				}
	
				node_poten(t).val[label-1] = (double)exp(tmp);
			}

		}
	}else
	{
		for(t=1; t <= SEQ_LEN; t++)
		{
			for(label=1; label <= LABEL_SIZE; label++)
			{
				node_poten(t).val[label-1] = (double)exp(node_param[label-1]);
			}
		}
	}


	if(TRANSIT_FEATURE)
	{
		for(t=1; t <= SEQ_LEN-1; t++)
		{
			for(pre_label=1; pre_label <= LABEL_SIZE; pre_label++)
			{
				for(label=1; label <= LABEL_SIZE; label++)
				{
					tmp = 0;
					flag = feature->getNextDataPattern(t,&f,&f_ID,true);
					while(flag)
					{	
						tmp += f*transit_param[transit_f_index(pre_label,label,f_ID)];
						flag = feature->getNextDataPattern(t,&f,&f_ID,false);
					}
					tmp = (double)exp(tmp);

					transit_poten(t).val[transit_st_index(pre_label,label)] = tmp;
				}
			}
		}
	}else
	{
		for(t=1; t <= SEQ_LEN-1; t++)
		{
			for(pre_label=1; pre_label <= LABEL_SIZE; pre_label++)
			{
				for(label=1; label <= LABEL_SIZE; label++)
				{
					f_index = transit_st_index(pre_label,label);
					transit_poten(t).val[f_index] = (double)exp(transit_param[f_index]);;
				}
			}
		}
	}


	//trinode potentials using only INDICATORs
	if(MARKOV_ORDER==SECOND)
	{
		for(pre_label=1; pre_label <= LABEL_SIZE; pre_label++)
		{
			for(label=1; label <= LABEL_SIZE; label++)
			{
				for(post_label=1; post_label <= LABEL_SIZE; post_label++)
				{
					trinode_poten(pre_label,label,post_label) = (double)exp(trinode_param(pre_label,label,post_label));
				}
			}
		}
	}
}


//compute the node and transit marginals
double SeqCRF::computeMarginFirstOrder()
{
	int pre_label, label, post_label,t,i,j;
	double Z_tmp;
	double log_Z=0;

	if(!MARGIN_INITED)
	{
		this->initMargin();
	}

	//--computing the potentials
	if(!POTEN_COMPUTED)
	{
		this->computePoten();
	}

	if(MSG_INITED)
	{
		this->clearMsg();
	}
	this->initMsg();

	//----------- forward messages -----------------
	for(t=2; t <= SEQ_LEN; t++)
	{
		zeros(forward(t).val,LABEL_SIZE);

		for(i=0; i < label_set(t).len; i++)
		{
			label = (int)label_set(t).val[i];

			for(j=0; j < label_set(t-1).len; j++)
			{
				pre_label = (int)label_set(t-1).val[j];

				forward(t).val[label-1] += forward(t-1).val[pre_label-1]*
						node_poten(t-1).val[pre_label-1]*
						transit_poten(t-1).val[transit_st_index(pre_label,label)];
			}
		}

		//normalisation => avoiding numerical overflow
		Z_tmp = normalise(forward(t).val,LABEL_SIZE);

		log_Z += (double)log(Z_tmp);
	}	
	//the last node
	Z_tmp = 0;
	for(i=0; i < label_set(SEQ_LEN).len; i++)
	{
		label = (int)label_set(SEQ_LEN).val[i];

		Z_tmp += forward(SEQ_LEN).val[label-1]*node_poten(SEQ_LEN).val[label-1];
	}
	log_Z += (double)log(Z_tmp);


	//----------  backward messages  -------------------
	double log_Z2=0;
	for(t=SEQ_LEN-1; t >= 1; t--)
	{
		zeros(backward(t).val,LABEL_SIZE);

		for(i=0; i < label_set(t).len; i++)
		{
			label = (int)label_set(t).val[i];

			for(j=0; j < label_set(t+1).len; j++)
			{
				post_label = (int)label_set(t+1).val[j];

				backward(t).val[label-1] += backward(t+1).val[post_label-1]*
							node_poten(t+1).val[post_label-1]*
							transit_poten(t).val[transit_st_index(label,post_label)];
			}
		}

		//normalisation => avoiding numerical overflow
		Z_tmp = normalise(backward(t).val,LABEL_SIZE);
		log_Z2 += (double)log(Z_tmp);
	}	
	//the first node
	Z_tmp = 0;
	for(i=0; i < label_set(1).len; i++)
	{
		label = (int)label_set(1).val[i];
		Z_tmp +=  backward(1).val[label-1]*node_poten(1).val[label-1];
	}
	log_Z2 += (double)log(Z_tmp);

	if(fabs(log_Z - log_Z2) > 1e-10)
	{
		cout << "log_Z: " << log_Z << "log_Z2: " << log_Z2 << " diff Z: " << log_Z - log_Z2 << endl;
	}

	//------- the marginals ------------------------

	//-the node marginals
	for(t=1; t <= SEQ_LEN; t++)
	{
		zeros(node_margin(t).val,LABEL_SIZE);
		for(i=0; i < label_set(t).len; i++)
		{
			label = (int)label_set(t).val[i];

			node_margin(t).val[label-1] = forward(t).val[label-1]*
				backward(t).val[label-1]*node_poten(t).val[label-1];
		}
		
		normalise(node_margin(t).val,LABEL_SIZE);
	}
	//-the transit marginals
	int val_index;
	for(t=1; t <= SEQ_LEN-1; t++)
	{
		zeros(transit_margin(t).val,LABEL_SIZE*LABEL_SIZE);

		for(i=0; i < label_set(t).len; i++)
		{
			label = (int)label_set(t).val[i];

			for(j=0; j < label_set(t+1).len; j++)
			{
				post_label = (int)label_set(t+1).val[j];

				val_index = (label-1)*LABEL_SIZE+post_label-1;

				transit_margin(t).val[val_index] = 
					forward(t).val[label-1]*node_poten(t).val[label-1]*
					backward(t+1).val[post_label-1]*node_poten(t+1).val[post_label-1]*
					transit_poten(t).val[transit_st_index(label,post_label)];
			}
		}

		//normalisation
		normalise(transit_margin(t).val,LABEL_SIZE*LABEL_SIZE);
	}

	return log_Z;
}

//compute the node and transit marginals
double SeqCRF::computeMarginSecondOrder()
{
	int pre_label, label, post_label,t,i,j,k;
	double Z_tmp;
	double log_Z=0;

	if(!MARGIN_INITED)
	{
		this->initMargin();
	}

	//--computing the potentials
	if(!POTEN_COMPUTED)
	{
		this->computePoten();
	}

	if(MSG_INITED)
	{
		this->clearMsg();
	}
	this->initMsg();

	if(SEQ_LEN <= 2)
	{
		return this->SeqCRF::computeMarginFirstOrder();
	}

	//----------- forward messages -----------------
	int index, pre_index;
	for(t=3; t <= SEQ_LEN; t++)
	{
		zeros(forward(t).val,LABEL_SIZE*LABEL_SIZE);

		for(i=0; i < label_set(t-1).len; i++)
		{
			label = (int)label_set(t-1).val[i];

			for(k=0; k < label_set(t).len; k++)
			{
				post_label = (int)label_set(t).val[k];
				index = (label-1)*LABEL_SIZE+post_label-1;

				for(j=0; j < label_set(t-2).len; j++)
				{
					pre_label = (int)label_set(t-2).val[j];
					pre_index = (pre_label-1)*LABEL_SIZE + label-1;

					forward(t).val[index] += forward(t-1).val[pre_index]*
						node_poten(t-2).val[pre_label-1]*
						transit_poten(t-2).val[transit_st_index(pre_label,label)]*
						trinode_poten(pre_label,label,post_label);
				}
			}
		}

		//normalisation => avoiding numerical overflow
		Z_tmp = normalise(forward(t).val,LABEL_SIZE*LABEL_SIZE);

		log_Z += (double)log(Z_tmp);
	}	
	//the last two nodes
	Z_tmp = 0;
	for(j=0; j < label_set(SEQ_LEN-1).len; j++)
	{
		pre_label = (int)label_set(SEQ_LEN-1).val[j];

		for(i=0; i < label_set(SEQ_LEN).len; i++)
		{
			label = (int)label_set(SEQ_LEN).val[i];
			index = (pre_label-1)*LABEL_SIZE + label-1;

			Z_tmp += forward(SEQ_LEN).val[index]*
					node_poten(SEQ_LEN-1).val[pre_label-1]*
					transit_poten(SEQ_LEN-1).val[transit_st_index(pre_label,label)]*
					node_poten(SEQ_LEN).val[label-1];
		}
	}
	log_Z += (double)log(Z_tmp);


	//----------  backward messages  -------------------
	double log_Z2=0;
	for(t=SEQ_LEN-2; t >= 1; t--)
	{
		zeros(backward(t).val,LABEL_SIZE*LABEL_SIZE);

		for(k=0; k < label_set(t).len; k++)
		{
			pre_label = (int)label_set(t).val[k];

			for(i=0; i < label_set(t+1).len; i++)
			{
				label = (int)label_set(t+1).val[i];
				pre_index = (pre_label-1)*LABEL_SIZE + label-1;

				for(j=0; j < label_set(t+2).len; j++)
				{
					post_label = (int)label_set(t+2).val[j];
					index = (label-1)*LABEL_SIZE + post_label-1;

					backward(t).val[pre_index] += backward(t+1).val[index]*
							node_poten(t+2).val[post_label-1]*
							transit_poten(t+1).val[transit_st_index(label,post_label)]*
							trinode_poten(pre_label,label,post_label);
				}
			}
		}

		//normalisation => avoiding numerical overflow
		Z_tmp = normalise(backward(t).val,LABEL_SIZE*LABEL_SIZE);
		log_Z2 += (double)log(Z_tmp);
	}	
	//the first two nodes
	Z_tmp = 0;
	for(i=0; i < label_set(1).len; i++)
	{
		label = (int)label_set(1).val[i];
		for(j=0; j < label_set(2).len; j++)
		{
			post_label = (int)label_set(2).val[j];
			index = (label-1)*LABEL_SIZE + post_label-1;
			
			Z_tmp +=  backward(1).val[index]*
						node_poten(2).val[post_label-1]*
						transit_poten(1).val[transit_st_index(label,post_label)]*
						node_poten(1).val[label-1];
		}
	}
	log_Z2 += (double)log(Z_tmp);

	if(fabs(log_Z - log_Z2) > 1e-10)
	{
		cout << "log_Z: " << log_Z << "log_Z2: " << log_Z2 << " diff Z: " << log_Z - log_Z2 << endl;
	}

	//------- the marginals ------------------------

	int index2;
	for(t=1; t <= SEQ_LEN-2; t++)
	{
		zeros(trinode_margin(t).val,LABEL_SIZE*LABEL_SIZE*LABEL_SIZE);
		zeros(transit_margin(t).val,LABEL_SIZE*LABEL_SIZE);
		zeros(node_margin(t).val,LABEL_SIZE);

		for(k=0; k < label_set(t).len; k++)
		{
			pre_label = (int)label_set(t).val[k];

			for(i=0; i < label_set(t+1).len; i++)
			{
				label = (int)label_set(t+1).val[i];
				pre_index = (pre_label-1)*LABEL_SIZE + label-1;

				for(j=0; j < label_set(t+2).len; j++)
				{
					post_label = (int)label_set(t+2).val[j];
					index = (label-1)*LABEL_SIZE + post_label-1;
						
					index2 = (pre_label-1)*LABEL_SIZE*LABEL_SIZE + (label-1)*LABEL_SIZE + post_label-1;

					trinode_margin(t).val[index2] = 
						forward(t+1).val[pre_index]*
						node_poten(t).val[pre_label-1]*
						transit_poten(t).val[transit_st_index(pre_label,label)]*
						node_poten(t+1).val[label-1]*
						transit_poten(t+1).val[transit_st_index(label,post_label)]*
						node_poten(t+2).val[post_label-1]*
						trinode_poten(pre_label,label,post_label)*
						backward(t+1).val[index];

					transit_margin(t).val[pre_index] += trinode_margin(t).val[index2];
				}

				node_margin(t).val[pre_label-1] += transit_margin(t).val[pre_index];
			}
		}
		normalise(trinode_margin(t).val,LABEL_SIZE*LABEL_SIZE*LABEL_SIZE);
		normalise(transit_margin(t).val,LABEL_SIZE*LABEL_SIZE);
		normalise(node_margin(t).val,LABEL_SIZE);
	}
	
	zeros(transit_margin(SEQ_LEN-1).val,LABEL_SIZE*LABEL_SIZE);
	zeros(node_margin(SEQ_LEN-1).val,LABEL_SIZE);
	for(i=0; i < label_set(SEQ_LEN-1).len; i++)
	{
		label = (int)label_set(SEQ_LEN-1).val[i];

		for(j=0; j < label_set(SEQ_LEN).len; j++)
		{
			post_label = (int)label_set(SEQ_LEN).val[j];
			index = (label-1)*LABEL_SIZE + post_label-1;

			for(k=0; k < label_set(SEQ_LEN-2).len; k++)
			{
				pre_label = (int)label_set(SEQ_LEN-2).val[k];
						
				index2 = (pre_label-1)*LABEL_SIZE*LABEL_SIZE + (label-1)*LABEL_SIZE + post_label-1;

				transit_margin(SEQ_LEN-1).val[index] +=
					trinode_margin(SEQ_LEN-2).val[index2]; 
			}

			node_margin(SEQ_LEN-1).val[label-1] += transit_margin(SEQ_LEN-1).val[index]; 
		}
	}
	
	zeros(node_margin(SEQ_LEN).val,LABEL_SIZE);
	for(j=0; j < label_set(SEQ_LEN).len; j++)
	{
		post_label = (int)label_set(SEQ_LEN).val[j];
		for(i=0; i < label_set(SEQ_LEN-1).len; i++)
		{
			label = (int)label_set(SEQ_LEN-1).val[i];
			index = (label-1)*LABEL_SIZE + post_label-1;
			
			node_margin(SEQ_LEN).val[post_label-1] += transit_margin(SEQ_LEN-1).val[index]; 
		}
	}

	return log_Z;
}

/*
	compute the gradients (corresponding label node and transit parameters)
	
	input:
		double *node_grad; //gradient with respect label nodes
		double *transit_grad;  //gradient with respect label transits
*/
double SeqCRF::getGrad(double *node_grad, double *transit_grad)
{
	//-- potentials -------
	this->computePoten();

	//--the clamp phase----------------------
	if(LABEL_SET_INITED)
	{
		this->clearStSet();
	}
	this->initStSet(CLAMP);
	double log_Z_semi = this->computeMarginFirstOrder();
	this->computeFeatureExpect();

	copy_vector(node_f_expect,node_grad,NODE_VEC_SIZE);
	copy_vector(transit_f_expect,transit_grad,TRANSIT_VEC_SIZE);

	//--the free phase----------------------
	this->clearStSet();
	this->initStSet(FREE);
	double log_Z = this->computeMarginFirstOrder();
	this->computeFeatureExpect();
	
	substract_vector(node_grad,node_f_expect,NODE_VEC_SIZE);
	substract_vector(transit_grad,transit_f_expect,TRANSIT_VEC_SIZE);

	return log_Z_semi - log_Z;
}



/*
	For FULLY OBSERVED data
*/
double SeqCRF::getGradFull(double *node_grad, double *transit_grad)
{
	//-- potentials -------
	this->computePoten();

	//--the clamp phase----------------------
	double log_Z_semi = this->computeFeatureExpectEmpi();
	copy_vector(node_f_expect,node_grad,NODE_VEC_SIZE);
	copy_vector(transit_f_expect,transit_grad,TRANSIT_VEC_SIZE);

	//--the free phase----------------------
	if(LABEL_SET_INITED)
	{
		this->clearStSet();
	}
	this->initStSet(FREE);
	double log_Z = this->computeMarginFirstOrder();
	this->computeFeatureExpect();
	
	substract_vector(node_grad,node_f_expect,NODE_VEC_SIZE);
	substract_vector(transit_grad,transit_f_expect,TRANSIT_VEC_SIZE);

	return log_Z_semi - log_Z;
}


/*
	compute the gradients (corresponding label node and transit parameters)
	
	input:
		double *node_grad; //gradient with respect to nodes
		double *transit_grad;  //gradient with respect to transits
		double *trinode_grad; //gradient with respect to second-order transitions
*/
double SeqCRF::getGrad(double *node_grad, double *transit_grad, double *trinode_grad)
{
	//-- potentials -------
	this->computePoten();

	//--the clamp phase----------------------
	if(LABEL_SET_INITED)
	{
		this->clearStSet();
	}
	this->initStSet(CLAMP);
	double log_Z_semi = this->computeMarginSecondOrder();
	this->computeFeatureExpect();

	copy_vector(node_f_expect,node_grad,NODE_VEC_SIZE);
	copy_vector(transit_f_expect,transit_grad,TRANSIT_VEC_SIZE);
	copy_vector(trinode_f_expect,trinode_grad,TRINODE_VEC_SIZE);

	//--the free phase----------------------
	this->clearStSet();
	this->initStSet(FREE);
	double log_Z = this->computeMarginSecondOrder();
	this->computeFeatureExpect();
	
	substract_vector(node_grad,node_f_expect,NODE_VEC_SIZE);
	substract_vector(transit_grad,transit_f_expect,TRANSIT_VEC_SIZE);
	substract_vector(trinode_grad,trinode_f_expect,TRINODE_VEC_SIZE);

	return log_Z_semi - log_Z;
}


/*
	For FULLY OBSERVED data
*/
double SeqCRF::getGradFull(double *node_grad, double *transit_grad, double *trinode_grad)
{
	//-- potentials -------
	this->computePoten();

	//--the clamp phase----------------------
	double log_Z_semi = this->computeFeatureExpectEmpi();

	copy_vector(node_f_expect,node_grad,NODE_VEC_SIZE);
	copy_vector(transit_f_expect,transit_grad,TRANSIT_VEC_SIZE);
	copy_vector(trinode_f_expect,trinode_grad,TRINODE_VEC_SIZE);


	//--the free phase----------------------
	if(LABEL_SET_INITED)
	{
		this->clearStSet();
	}
	this->initStSet(FREE);
	double log_Z;
	if(SEQ_LEN <= 2)
	{
		log_Z = this->computeMarginFirstOrder();
	}else
	{
		log_Z = this->computeMarginSecondOrder();
	}
	this->computeFeatureExpect();
	
	substract_vector(node_grad,node_f_expect,NODE_VEC_SIZE);
	substract_vector(transit_grad,transit_f_expect,TRANSIT_VEC_SIZE);
	substract_vector(trinode_grad,trinode_f_expect,TRINODE_VEC_SIZE);

	return log_Z_semi - log_Z;
}

void SeqCRF::setParam(double *node_paramx)
{
	node_param = node_paramx;
}

void SeqCRF::setParam(double *node_paramx, double *transit_paramx)
{
	node_param = node_paramx;
	transit_param = transit_paramx;
}

void SeqCRF::setParam(double *node_paramx, double *transit_paramx, double *trinode_paramx)
{
	node_param = node_paramx;
	transit_param = transit_paramx;
	trinode_param = trinode_paramx;
}

void SeqCRF::setLabel(int *label)
{
	label_data = label;
}

/*
	perform standard Viterbi decoding, 
	assuming parameters and features have been submitted
*/
void SeqCRF::viterbi(int *label_predicts)
{
	int pre_label, label, t, max_pre_label,i,j;
	double tmp, max_val;

	int *bookkeeper = new int[SEQ_LEN*LABEL_SIZE];
	double forward_max, forward_tmp;

	//----------- forward messages -----------------
	for(t=2; t <= SEQ_LEN; t++)
	{
		zeros(forward(t).val,LABEL_SIZE);

		for(i=0; i < label_set(t).len; i++)
		{
			label = (int)label_set(t).val[i];

			forward_max = 0;
			for(j=0; j < label_set(t-1).len; j++)
			{
				pre_label = (int)label_set(t-1).val[j];

				forward_tmp = forward(t-1).val[pre_label-1]*
							node_poten(t-1).val[pre_label-1]*
							transit_poten(t-1).val[transit_st_index(pre_label,label)];

				if(forward_max < forward_tmp)
				{
					forward_max = forward_tmp;
				}
			}

			forward(t).val[label-1] = forward_max;
		}
		normalise(forward(t).val,LABEL_SIZE);

	}

	//the last node
	max_pre_label = 1;
	max_val = -1e+10;
	for(i=0; i < label_set(t).len; i++)
	{
		label = (int)label_set(t).val[i];

		tmp = forward(SEQ_LEN).val[label-1]*node_poten(SEQ_LEN).val[label-1];
		if(max_val < tmp)
		{
			max_val = tmp;
			max_pre_label = label;
		}
	}
	label_predicts[SEQ_LEN-1] = max_pre_label;

	//----------- backtracking -----------------
	for(t=SEQ_LEN-1; t >= 1; t--)
	{
		max_pre_label = label_predicts[t];
		label_predicts[t-1] = bookkeeper(t+1,max_pre_label);
	}

	delete [] bookkeeper;
}

//a backward version of viterbi()
void SeqCRF::viterbiBackward(int *label_predicts)
{
	int post_label, label, t, max_post_label,i,j;
	double tmp, max_val;

	int *bookkeeper = new int[SEQ_LEN*LABEL_SIZE];
	double backward_max, backward_tmp;

	//----------  backward messages  -------------------
	for(t=SEQ_LEN-1; t >= 1; t--)
	{
		zeros(backward(t).val,LABEL_SIZE);

		for(i=0; i < label_set(t).len; i++)
		{
			label = (int)label_set(t).val[i];

			backward_max = 0;
			for(j=0; j < label_set(t+1).len; j++)
			{
				post_label = (int)label_set(t+1).val[j];

				 backward_tmp = backward(t+1).val[post_label-1]*
							node_poten(t+1).val[post_label-1]*
							transit_poten(t).val[transit_st_index(label,post_label)];
				 if(backward_max < backward_tmp)
				 {
					 backward_max = backward_tmp;
				 }
			}

			backward(t).val[label-1] = backward_max;
		}
		normalise(backward(t).val,LABEL_SIZE);
	}	
	//the first node
	max_post_label = 1;
	max_val = -1e+10;
	for(i=0; i < label_set(t).len; i++)
	{
		label = (int)label_set(t).val[i];

		tmp = backward(1).val[label-1]*node_poten(1).val[label-1];;
		if(max_val < tmp)
		{
			max_val = tmp;
			max_post_label = label;
		}
	}
	label_predicts[0] = max_post_label;

	//----------- forward-tracking -----------------
	for(t=1; t <= SEQ_LEN-1; t++)
	{
		max_post_label = label_predicts[t-1];
		label_predicts[t] = bookkeeper(t,max_post_label);
	}

	delete [] bookkeeper;
}


/*
	filling the state set per node
*/
void SeqCRF::initStSet(int mode)
{
	LABEL_SET_INITED = true;
	int label,t;
 
	label_set = new MarkovUnit[SEQ_LEN];
	for(t=1; t <= SEQ_LEN; t++)
	{
		if(mode == CLAMP && label_data(t) > 0)
		{
			label_set(t).len = 1;
			label_set(t).val = new double[1];
			label_set(t).val[0] = (double)label_data(t);
		}else
		{
			label_set(t).len = LABEL_SIZE;
			label_set(t).val = new double[LABEL_SIZE];
			for(label=1; label <= LABEL_SIZE; label++)
			{
				label_set(t).val[label-1] = (double)label;
			}
		}
	}
}

void SeqCRF::clearStSet()
{
	LABEL_SET_INITED = false;
	int t;

	for(t=1; t <= SEQ_LEN; t++)
	{
		delete [] label_set(t).val;
	}

	delete [] label_set;
}

void SeqCRF::initMsg()
{
	MSG_INITED = true;

	int t;

	forward = new MarkovUnit[SEQ_LEN];
	backward = new MarkovUnit[SEQ_LEN];

	for(t=1; t <= SEQ_LEN; t++)
	{
		if(MARKOV_ORDER==FIRST)
		{
			forward(t).val = new double[LABEL_SIZE];
			backward(t).val = new double[LABEL_SIZE];
			ones(forward(t).val,LABEL_SIZE);
			ones(backward(t).val,LABEL_SIZE);
		}else if(MARKOV_ORDER==SECOND)
		{
			forward(t).val = new double[LABEL_SIZE*LABEL_SIZE];
			backward(t).val = new double[LABEL_SIZE*LABEL_SIZE];
			ones(forward(t).val,LABEL_SIZE*LABEL_SIZE);
			ones(backward(t).val,LABEL_SIZE*LABEL_SIZE);
		}
	}
}

void SeqCRF::clearMsg()
{
	MSG_INITED = false;

	int t;

	for(t=1; t <= SEQ_LEN; t++)
	{
		delete [] forward(t).val;
		delete [] backward(t).val;
	}

	delete [] forward;
	delete [] backward;
}

/*
	feature expectation
*/
void SeqCRF::computeFeatureExpect()
{
	int t, val_index;
	int i,j,label,pre_label;
	double f;
	int f_ID,flag;

	//-- initialisation ---- 
	if(!F_EXPECT_INITED)
	{
		node_f_expect = new double[NODE_VEC_SIZE];
		transit_f_expect = new double[TRANSIT_VEC_SIZE];
		if(MARKOV_ORDER == SECOND)
		{
			trinode_f_expect = new double[TRINODE_VEC_SIZE];
		}
		F_EXPECT_INITED = true;
	}
	zeros(node_f_expect,NODE_VEC_SIZE);
	zeros(transit_f_expect,TRANSIT_VEC_SIZE);
	if(MARKOV_ORDER == SECOND)
	{
		zeros(trinode_f_expect,TRINODE_VEC_SIZE);
	}

	//-- node-based feature expectation ----
	if(NODE_FEATURE)
	{
		for(t=1; t <= SEQ_LEN; t++)
		{
			flag = feature->getNextDataPattern(t,&f,&f_ID,true);
			while(flag)
			{
				for(i=0; i < label_set(t).len; i++)
				{
					label = (int)label_set(t).val[i];

					node_f_expect[node_f_index(label,f_ID)] += 
							(double)node_margin(t).val[label-1]*f;
				}

				flag = feature->getNextDataPattern(t,&f,&f_ID,false);
			}
		}
	}else
	{
		for(t=1; t <= SEQ_LEN; t++)
		{
			for(i=0; i < label_set(t).len; i++)
			{
				label = (int)label_set(t).val[i];

				node_f_expect[label-1] += 
						(double)node_margin(t).val[label-1];
			}
		}
	}

	//-- transition horizontal edge feature expectation ----------
	if(TRANSIT_FEATURE)
	{
		for(t=1; t <= SEQ_LEN-1; t++)
		{
			flag = feature->getNextDataPattern(t,&f,&f_ID,true);
			while(flag)
			{
				for(i=0; i < label_set(t).len; i++)
				{
					pre_label = (int)label_set(t).val[i];
					for(j=0; j < label_set(t+1).len; j++)
					{
						label = (int)label_set(t+1).val[j];

						transit_f_expect[transit_f_index(pre_label,label,f_ID)] += 
							(double)transit_margin(t).val[transit_st_index(pre_label,label)]*f;
					}
				}

				flag = feature->getNextDataPattern(t,&f,&f_ID,false);
			}
		}
	}else
	{
		for(t=1; t <= SEQ_LEN-1; t++)
		{
			for(i=0; i < label_set(t).len; i++)
			{
				pre_label = (int)label_set(t).val[i];
				for(j=0; j < label_set(t+1).len; j++)
				{
					label = (int)label_set(t+1).val[j];

					transit_f_expect(pre_label,label) += 
						(double)transit_margin(t).val[transit_st_index(pre_label,label)];
				}
			}
		}
	}

	if(MARKOV_ORDER == SECOND && SEQ_LEN > 2)
	{
		int post_label,k;
		//-- second order trinode feature expectation ----------
		for(t=1; t <= SEQ_LEN-2; t++)
		{
			for(i=0; i < label_set(t).len; i++)
			{
				pre_label = (int)label_set(t).val[i];
				for(j=0; j < label_set(t+1).len; j++)
				{
					label = (int)label_set(t+1).val[j];

					for(k=0; k < label_set(t+2).len; k++)
					{
						post_label = (int)label_set(t+2).val[k];

						val_index = (pre_label-1)*LABEL_SIZE*LABEL_SIZE + (label-1)*LABEL_SIZE + post_label-1;

						trinode_f_expect(pre_label,label,post_label) += (double)trinode_margin(t).val[val_index];
					}
				}
			}
		}
	}
}

void SeqCRF::getMAP(int *label_predicts)
{
	//-- the set of states per node --
	if(LABEL_SET_INITED)
	{
		this->clearStSet();
	}
	this->initStSet(FREE);

	//--computing the potentials
	if(POTEN_COMPUTED)
	{
		this->clearPoten();
	}
	this->computePoten();

	//-- updating the sum-product messages
	if(!MSG_INITED)
	{
		this->initMsg();
	}

	if(MARKOV_ORDER == FIRST || SEQ_LEN <= 2)
	{
		this->maxProdFirstOrder(label_predicts);
		//this->viterbi(label_predicts);
		//this->viterbiBackward(label_predicts);
	}else if(MARKOV_ORDER == SECOND)
	{
		this->maxProdSecondOrder(label_predicts);
	}
}


/*
	Decoding the best label sequence for the First-order CRFs
*/
void SeqCRF::maxProdFirstOrder(int *label_predicts)
{
	int t, label, label_max,i,j,pre_label,post_label;
	double margin_max, margin_tmp;
	double forward_max, forward_tmp;
	double backward_max, backward_tmp;

	//----------- forward messages -----------------
	for(t=2; t <= SEQ_LEN; t++)
	{
		zeros(forward(t).val,LABEL_SIZE);

		for(i=0; i < label_set(t).len; i++)
		{
			label = (int)label_set(t).val[i];

			forward_max = 0;
			for(j=0; j < label_set(t-1).len; j++)
			{
				pre_label = (int)label_set(t-1).val[j];

				forward_tmp = forward(t-1).val[pre_label-1]*
							node_poten(t-1).val[pre_label-1]*
							transit_poten(t-1).val[transit_st_index(pre_label,label)];

				if(forward_max < forward_tmp)
				{
					forward_max = forward_tmp;
				}
			}

			forward(t).val[label-1] = forward_max;
		}
		normalise(forward(t).val,LABEL_SIZE);

	}	

	//----------  backward messages  -------------------
	for(t=SEQ_LEN-1; t >= 1; t--)
	{
		zeros(backward(t).val,LABEL_SIZE);

		for(i=0; i < label_set(t).len; i++)
		{
			label = (int)label_set(t).val[i];

			backward_max = 0;
			for(j=0; j < label_set(t+1).len; j++)
			{
				post_label = (int)label_set(t+1).val[j];

				 backward_tmp = backward(t+1).val[post_label-1]*
							node_poten(t+1).val[post_label-1]*
							transit_poten(t).val[transit_st_index(label,post_label)];
				 if(backward_max < backward_tmp)
				 {
					 backward_max = backward_tmp;
				 }
			}

			backward(t).val[label-1] = backward_max;
		}
		normalise(backward(t).val,LABEL_SIZE);
	}	

	//------- the max marginals ------------------------
	for(t=1; t <= SEQ_LEN; t++)
	{
		margin_max = 0;
		for(i=0; i < label_set(t).len; i++)
		{
			label = (int)label_set(t).val[i];

			margin_tmp = forward(t).val[label-1]*
				backward(t).val[label-1]*node_poten(t).val[label-1];

			if(margin_max < margin_tmp)
			{
				margin_max = margin_tmp;
				label_max = label;
			}
		}
		
		label_predicts(t) = label_max;
	}
}

/*
	Decoding the best label sequence for the Second-order CRFs
*/
void SeqCRF::maxProdSecondOrder(int *label_predicts)
{
	int t, label, label_max,i,j,k,pre_label,post_label;
	double margin_max, margin_tmp;
	double forward_max, forward_tmp;
	double backward_max, backward_tmp;

	//----------- forward messages -----------------
	int index, pre_index;
	for(t=3; t <= SEQ_LEN; t++)
	{
		zeros(forward(t).val,LABEL_SIZE*LABEL_SIZE);

		for(i=0; i < label_set(t-1).len; i++)
		{
			label = (int)label_set(t-1).val[i];

			for(k=0; k < label_set(t).len; k++)
			{
				post_label = (int)label_set(t).val[k];
				index = (label-1)*LABEL_SIZE+post_label-1;

				forward_max=0;
				for(j=0; j < label_set(t-2).len; j++)
				{
					pre_label = (int)label_set(t-2).val[j];
					pre_index = (pre_label-1)*LABEL_SIZE + label-1;

					 forward_tmp = forward(t-1).val[pre_index]*
						node_poten(t-2).val[pre_label-1]*
						transit_poten(t-2).val[transit_st_index(pre_label,label)]*
						trinode_poten(pre_label,label,post_label);
					 forward_max = (forward_max < forward_tmp)? forward_tmp:forward_max;
				}

				forward(t).val[index] = forward_max;
			}
		}

		//normalisation => avoiding numerical overflow
		normalise(forward(t).val,LABEL_SIZE*LABEL_SIZE);
	}	

	//----------  backward messages  -------------------
	for(t=SEQ_LEN-2; t >= 1; t--)
	{
		zeros(backward(t).val,LABEL_SIZE*LABEL_SIZE);

		for(k=0; k < label_set(t).len; k++)
		{
			pre_label = (int)label_set(t).val[k];

			for(i=0; i < label_set(t+1).len; i++)
			{
				label = (int)label_set(t+1).val[i];
				pre_index = (pre_label-1)*LABEL_SIZE + label-1;

				backward_max = 0;
				for(j=0; j < label_set(t+2).len; j++)
				{
					post_label = (int)label_set(t+2).val[j];
					index = (label-1)*LABEL_SIZE + post_label-1;

					backward_tmp = backward(t+1).val[index]*
							node_poten(t+2).val[post_label-1]*
							transit_poten(t+1).val[transit_st_index(label,post_label)]*
							trinode_poten(pre_label,label,post_label);
					backward_max = (backward_max < backward_tmp)? backward_tmp:backward_max;
				}

				backward(t).val[pre_index] = backward_max;
			}
		}

		//normalisation => avoiding numerical overflow
		normalise(backward(t).val,LABEL_SIZE*LABEL_SIZE);
	}	
	//------- the max marginals ------------------------
	int post_label_max;
	for(t=1; t <= SEQ_LEN-1; t++)
	{
		margin_max = 0;
		for(i=0; i < label_set(t).len; i++)
		{
			label = (int)label_set(t).val[i];

			for(j=0; j < label_set(t+1).len; j++)
			{
				post_label = (int)label_set(t+1).val[j];

				index = (label-1)*LABEL_SIZE + post_label-1;

				margin_tmp = forward(t+1).val[index]*
						node_poten(t).val[label-1]*
						transit_poten(t).val[transit_st_index(label,post_label)]*
						node_poten(t+1).val[post_label-1]*
						backward(t).val[index];

				if(margin_max < margin_tmp)
				{
					margin_max = margin_tmp;
					label_max = label;
					post_label_max = post_label;
				}
			}
		}
		
		label_predicts(t) = label_max;
	}
	label_predicts(t) = post_label_max;

}
void SeqCRF::clearMargin()
{
	MARGIN_INITED = false;

	int t;

	//--- node marginals --
	for(t=1; t <= SEQ_LEN; t++)
	{
		delete [] node_margin(t).val;
	}

	delete [] node_margin;

	//--- transition marginals --
	for(t=1; t <= SEQ_LEN-1; t++)
	{
		delete [] transit_margin(t).val;
	}
	delete [] transit_margin;

	if(MARKOV_ORDER==SECOND)
	{
		//--- trinode marginals --
		for(t=1; t <= SEQ_LEN-2; t++)
		{
			delete [] trinode_margin(t).val;
		}

		delete [] trinode_margin;
	}
}

void SeqCRF::clearPoten()
{
	POTEN_INITED = false;
	POTEN_COMPUTED = false;

	//-- node potentials ---
	int t;
	for(t=1; t <= SEQ_LEN; t++)
	{
		delete [] node_poten(t).val;
	}
	delete [] node_poten;

	if(transit_poten)
	{
		for(t=1; t <= SEQ_LEN-1; t++)
		{
			delete [] transit_poten(t).val;
		}
		delete [] transit_poten;
	}

	if(trinode_poten)
	{
		delete [] trinode_poten;
	}
}

/*
	memory allocation for potentials
*/
void SeqCRF::initPoten()
{
	POTEN_INITED = true;

	//-- node potentials ---
	node_poten = new MarkovUnit[SEQ_LEN];

	int t;
	for(t=1; t <= SEQ_LEN; t++)
	{
		node_poten(t).val = new double[LABEL_SIZE];
		ones(node_poten(t).val,LABEL_SIZE);
	}

	//--the rest -----
	transit_poten = new MarkovUnit[SEQ_LEN-1];
	for(t=1; t <= SEQ_LEN-1; t++)
	{
		transit_poten(t).val = new double[LABEL_SIZE*LABEL_SIZE]; //the horizontal transition
		ones(transit_poten(t).val,LABEL_SIZE*LABEL_SIZE);
	}

	if(MARKOV_ORDER == SECOND)
	{
		trinode_poten = new double[LABEL_SIZE*LABEL_SIZE*LABEL_SIZE]; //the second order
		ones(trinode_poten,LABEL_SIZE*LABEL_SIZE*LABEL_SIZE);
	}
}

//allocating memory for marginals
void SeqCRF::initMargin()
{
	MARGIN_INITED = true;

	int t;

	//--- node marginals --
	node_margin = new MarkovUnit[SEQ_LEN];
	for(t=1; t <= SEQ_LEN; t++)
	{
		node_margin(t).val = new double[LABEL_SIZE];
	}


	//--- transition marginals --
	transit_margin = new MarkovUnit[SEQ_LEN-1];
	for(t=1; t <= SEQ_LEN-1; t++)
	{
		transit_margin(t).val = new double[LABEL_SIZE*LABEL_SIZE];
	}

	if(MARKOV_ORDER==SECOND)
	{
		//--- transition marginals --
		trinode_margin = new MarkovUnit[SEQ_LEN-2];
		for(t=1; t <= SEQ_LEN-2; t++)
		{
			trinode_margin(t).val = new double[LABEL_SIZE*LABEL_SIZE*LABEL_SIZE];
		}
	}
}

// empirical feature expectation
double SeqCRF::computeFeatureExpectEmpi()
{
	int t,label, post_label, post_post_label, flag,f_ID;
	double log_Z_semi=0;
	double f;

	//-- initialisation ---- 
	if(!F_EXPECT_INITED)
	{
		node_f_expect = new double[NODE_VEC_SIZE];
		transit_f_expect = new double[TRANSIT_VEC_SIZE];
		if(MARKOV_ORDER == SECOND)
		{
			trinode_f_expect = new double[TRINODE_VEC_SIZE];
		}
		F_EXPECT_INITED = true;
	}
	zeros(node_f_expect,NODE_VEC_SIZE);
	zeros(transit_f_expect,TRANSIT_VEC_SIZE);
	if(MARKOV_ORDER == SECOND)
	{
		zeros(trinode_f_expect,TRINODE_VEC_SIZE);
	}

	if(NODE_FEATURE)
	{
		for(t=1; t <= SEQ_LEN; t++)
		{
			label = label_data(t);

			flag = feature->getNextDataPattern(t,&f,&f_ID,true);
			while(flag)
			{
				node_f_expect[node_f_index(label,f_ID)] += f;
				log_Z_semi += node_param[node_f_index(label,f_ID)]*f;

				flag = feature->getNextDataPattern(t,&f,&f_ID,false);
			}
		}
	}else
	{
		for(t=1; t <= SEQ_LEN; t++)
		{
			label = label_data(t);

			node_f_expect[label-1]++;
			log_Z_semi += node_param[label-1];
		}
	}

	if(TRANSIT_FEATURE)
	{
		for(t=1; t <= SEQ_LEN-1; t++)
		{
			label = label_data(t);
			post_label = label_data(t+1);

			flag = feature->getNextDataPattern(t,&f,&f_ID,true);
			while(flag)
			{
				transit_f_expect[transit_f_index(label,post_label,f_ID)] += f;
				log_Z_semi += transit_param[transit_f_index(label,post_label,f_ID)]*f;

				flag = feature->getNextDataPattern(t,&f,&f_ID,false);
			}
		}
	}else
	{
		for(t=1; t <= SEQ_LEN-1; t++)
		{
			label = label_data(t);
			post_label = label_data(t+1);

			transit_f_expect(label,post_label)++;
			log_Z_semi += transit_param(label,post_label);
		}
	}

	if(MARKOV_ORDER == SECOND)
	{
		for(t=1; t <= SEQ_LEN-2; t++)
		{
			label = label_data(t);
			post_label = label_data(t+1);
			post_post_label = label_data(t+2);

			trinode_f_expect(label,post_label,post_post_label)++;
			log_Z_semi += trinode_param(label,post_label,post_post_label);
		}
	}

	return log_Z_semi;
}
