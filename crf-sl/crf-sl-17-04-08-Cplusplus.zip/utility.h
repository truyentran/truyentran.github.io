/*
	CRF-SL: Conditional Random Fields for Sequential Labelling

	Copyright (C) 2006-2008 Tran The Truyen <thetruyen.tran@postgrad.curtin.edu.au>
	This is free software with ABSOLUTELY NO WARRANTY.
  
	This library is free software; you can redistribute it and/or
	modify it under the terms of the GNU Lesser General Public
	License as published by the Free Software Foundation; either
	version 2.1 of the License, or (at your option) any later version.
  
	This library is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
	Lesser General Public License for more details.
  
	You should have received a copy of the GNU Lesser General Public
	License along with this library; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#if !defined (_UTILITY_H_)
#define _UTILITY_H_

//-------some matrix manipulation functionalities----------

//---------- function declarations ------------------
void init_vector(int *vector, int len, int val); //utility function to initialise vector
void init_vector(float *vector, int len, float val); //utility function to initialise vector
void init_vector(double *vector, int len, double val); //utility function to initialise vector

void zeros(int *vector, int len);
void zeros(float *vector, int len); //like MatLab zeros() function
void zeros(double *vector, int len); //like MatLab zeros() function

void ones(int *vector, int len);
void ones(float *vector, int len); //like MatLab ones() function
void ones(double *vector, int len); //like MatLab ones() function

void rand_vector(float *vector, int len);
void rand_vector(float *vector, float scale,int len);
void rand_vector(double *vector, int len);
void rand_vector(double *vector, double scale,int len);

void copy_vector(int *from, int *to, int len);
void copy_vector(float *from, float *to, int len);
void copy_vector(double *from, double *to, int len);

void add_vector(float *v1, float *v2, float *sum, int len);
void add_vector(float *v, float *more, int len);
void add_vector(double *v1, double *v2, float *sum, int len);
void add_vector(double *v, double *more, int len);

void add_scalar(float *v1, float c, int len);
void add_scalar(double *v1, double c, int len);

void multi_scalar(float *v, float c, int len);
void multi_scalar(double *v, double c, int len);

void div_scalar(float *v, float c, int len);
void div_scalar(double *v, double c, int len);

void log_vector(float *v, int len);
void log_vector(double *v, int len);

void exp_vector(float *v, int len);
void exp_vector(double *v, int len);

void substract_vector(float *from, float *less, float *diff, int len);
void substract_vector(float *from, float *less, int len);
void substract_vector(double *from, double *less, double *diff, int len);
void substract_vector(double *from, double *less, int len);

float inner_prod(float *v1, float *v2, int len);
double inner_prod(double *v1, double *v2, int len);

int sum_vector(int *v, int len);
float sum_vector(float *v, int len);
double sum_vector(double *v, int len);

float normalise(float *v, int len);
double normalise(double *v, int len);

int* abs_vector(int *v, int len);
float* abs_vector(float *v, int len);
double* abs_vector(double *v, int len);

int min_vector(int *v, int len);
float min_vector(float *v, int len);
double min_vector(double *v, int len);

int max_vector(int *v, int len);
float max_vector(float *v, int len);
double max_vector(double *v, int len);

int* join(int *head, int *tail, int *all, int head_len, int tail_len);
float* join(float *head, float *tail, float *all, int head_len, int tail_len);
double* join(double *head, double *tail, double *all, int head_len, int tail_len);

void extract(int *sub, int *full, int sub_start, int sub_len);
void extract(float *sub, float *full, int sub_start, int sub_len);
void extract(double *sub, double *full, int sub_start, int sub_len);

void insert(int *sub, int *full, int sub_start, int sub_len);
void insert(float *sub, float *full, int sub_start, int sub_len);
void insert(double *sub, double *full, int sub_start, int sub_len);

float distance(float *v1, float *v2, int len);
double distance(double *v1, double *v2, int len);

int s_len_trim ( char *s );

#endif //!defined(!defined (_UTILITY_H_)
