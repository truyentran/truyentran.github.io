/*
	CRF-SL: Conditional Random Fields for Sequential Labelling

	Copyright (C) 2006-2008 Tran The Truyen <thetruyen.tran@postgrad.curtin.edu.au>
	This is free software with ABSOLUTELY NO WARRANTY.
  
	This library is free software; you can redistribute it and/or
	modify it under the terms of the GNU Lesser General Public
	License as published by the Free Software Foundation; either
	version 2.1 of the License, or (at your option) any later version.
  
	This library is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
	Lesser General Public License for more details.
  
	You should have received a copy of the GNU Lesser General Public
	License along with this library; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <iostream.h>
#include <fstream.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include "Label.h"
#include "utility.h"

Label::Label()
{
	SEQ_LEN_INITED = false;
	LABELS_INITED = false;
}

Label::Label(int seq_no)
{
	SEQ_NO = seq_no;
	SEQ_LEN_INITED = false;

	label_all = new LabelStruct[SEQ_NO];
	LABELS_INITED = true;
}

Label::~Label()
{
	if(SEQ_LEN_INITED)
	{
		delete [] seq_lens;
	}

	if(LABELS_INITED)
	{
		int sq;
		for(sq=0; sq < SEQ_NO; sq++)
		{
			delete [] label_all[sq].labels;
		}

		delete [] label_all;
	}
}

int Label::readMatrices(char *file_name)
{
	ifstream input;
	char line[1024];
	char token[20];
	int i,j,val_index;
	int sq=0;
	

	//---------- READING THE STATE TAG FILE --------------------
	input.open(file_name);

	//check for wrong input file
	if (!input)
	{
		cout << "\n";
		cout << " Label::readMatrices() - Fatal error!\n";
		cout << "Could not read file: \"" << file_name << "\"\n";
		return 0;
	}

	//-------- extract the field numerical values ---------------
	bool new_sq = false;
	sq=0;
	label_all[sq].sq_ID = sq;
	label_all[sq].labels = new int[seq_lens[sq]];

	val_index = 0;
	while (input.getline(line,sizeof(line)) && !(input.eof()))
	{
		if (line[0] == '#')
		{ //this is a comment, ignore
			continue;
		}

		if(s_len_trim(line) == 0)
		{ //this is a gap between sequences, count only once
			if(!new_sq)
			{
				new_sq = true;
				sq++;
				
				val_index = 0; //val_index is for the whole sequence's layers

				label_all[sq].sq_ID = sq;
				label_all[sq].labels = new int[seq_lens[sq]];
			}

			continue;
		}else{
			new_sq = false;
		}


		i=0,j=0;
		while(line[i] != '\0')
		{
			if(line[i] == ' ' || line[i] == '\t')
			{ //end of state
				token[j] = '\0';
				label_all[sq].labels[val_index] = atoi(token);
				val_index++;

				j=0;
			}else{
				token[j] = line[i];
				j++;
			}

			i++;
		}
		//at the end of the line, extract the last state
		token[j] = '\0';
		label_all[sq].labels[val_index] = atoi(token);
		val_index++;
	}

	input.close();
 
	return 1;	
}

/*
	Each line is a sequence of labels, separated by an empty space. Sequences
	are separated by an empty line.

	Line format:
		1 2 1 -1 2 1
		
		2 3 -1 -1 0 2
	The value of -1 means the label is missing.

	ASSUMPTION: the observational features have been read

*/
int Label::readLabels(char *label_file)
{
	LABELS_INITED = true;

	ifstream input;
	char line[1024];
	int sq=0;
	

	//----- READING THE TAG FILE, COUNT THE NUMBER OF SEQUENCES -----
	input.open(label_file);

	//check for wrong input file
	if (!input)
	{
		cout << "\n";
		cout << " Label::readLabels() - Fatal error!\n";
		cout << "Could not read file: \"" << label_file << "\"\n";
		return 0;
	}

	bool new_sq = false;
	SEQ_NO=0;
	while (input.getline(line,sizeof(line)) && !(input.eof()))
	{
		if (line[0] == '#')
		{ //this is a comment, ignore
			continue;
		}

		if(s_len_trim(line) == 0)
		{ //this is a gap between sequences, count only once
			if(!new_sq)
			{
				new_sq = true;
				SEQ_NO++;
			}

			continue;
		}else{
			new_sq = false;

		}
	}
	input.close();

	SEQ_NO++;

	label_all = new LabelStruct[SEQ_NO];
	seq_lens = new int[SEQ_NO];
	SEQ_LEN_INITED = true;

	//-- COMPUTE THE SEQUENCE LENGTH --------
	input.open(label_file);
	new_sq = true;
	sq = 0;
	seq_lens[sq] = 0;
	while (input.getline(line,sizeof(line)) && !(input.eof()))
	{
		if (line[0] == '#')
		{ //this is a comment, ignore
			continue;
		}

		if(s_len_trim(line) == 0)
		{ //this is a gap between sequences, count only once
			if(!new_sq)
			{
				new_sq = true;
				sq++;
				seq_lens[sq] = 0;
			}

			continue;
		}

		if(new_sq)
		{
			new_sq = false;

			int i=0;
			while(line[i] != '\0')
			{
				if(line[i] == ' ' || line[i] == '\t')
				{ //end of state
					seq_lens[sq]++;
				}
				i++;
			}
			//end of line
			seq_lens[sq]++;
		}

	}
	input.close();

	//----- READING THE CONTENT OF THE TAG FILE -----
	return this->readMatrices(label_file);
}

int* Label::getLabels(int seq_i)
{
	return label_all[seq_i].labels;
}

int Label::getSeqLen(int seq_i)
{
	return seq_lens[seq_i];
}

int* Label::getSeqLens()
{
	return seq_lens;
}

int Label::getSeqNo()
{
	return SEQ_NO;
}

void Label::setSeqNo(int seq_no)
{
	SEQ_NO = seq_no;
}
 
void Label::setLabels(int sq, int *labels, int seq_len)
{
	label_all[sq].sq_ID = sq;
	label_all[sq].labels = new int[seq_len];
	copy_vector(labels,label_all[sq].labels,seq_len);
}
