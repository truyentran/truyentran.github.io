/*
	CRF-SL: Conditional Random Fields for Sequential Labelling

	Copyright (C) 2006-2008 Tran The Truyen <thetruyen.tran@postgrad.curtin.edu.au>
	This is free software with ABSOLUTELY NO WARRANTY.
  
	This library is free software; you can redistribute it and/or
	modify it under the terms of the GNU Lesser General Public
	License as published by the Free Software Foundation; either
	version 2.1 of the License, or (at your option) any later version.
  
	This library is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
	Lesser General Public License for more details.
  
	You should have received a copy of the GNU Lesser General Public
	License along with this library; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#if !defined(_LABEL_H_)
#define _LABEL_H_

class Label
{
public:
	void setLabels(int sq, int *Labels, int seq_len);
	
	void setSeqNo(int seq_no);

	int getSeqNo();
	int* getSeqLens();
	int* getLabels(int seq_i);
	int getSeqLen(int seq_i);
	int readLabels(char *Label_file);

	Label(int seq_no);
	Label();
	virtual ~Label();

private:
	void init(int depth);

	struct LabelStruct
	{
		int sq_ID;
		int *labels;
	};

	bool LABELS_INITED; //true when all the Labels are initialised
	bool SEQ_LEN_INITED; //true when the seqence length array is initialised.

	LabelStruct *label_all; //holding the Labels of all sequences

	int SEQ_NO; //number of sequences
	int *seq_lens; //the sequence length

	int readMatrices(char *file_name);
};

#endif // !defined(_LABEL_H_)
